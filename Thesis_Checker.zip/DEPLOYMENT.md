# Thesis Checker ni Jean Ko deployment

The standard Vercel deployment opens the browser-only checker directly. Run `npm run dev` locally or deploy the source root with the included `vercel.json`. The checker processes files in the browser and stores reports on that device. This build uses no Supabase or Railway environment variables.

The following instructions are for the optional account workspace. It provides email authentication, private uploads, document history, revisions, temporary download links, and document and account deletion. Server-side analysis of saved versions is a separate milestone.

## Requirements

- Node.js 24 and npm. Use `npm ci` to install the pinned dependency graph.
- A dedicated Supabase project with Auth, Data API, and Storage. For local development, use the Supabase CLI and a compatible Docker runtime.
- A Railway API service and Vercel frontend for staging. Keep the staging application access-restricted while testing student-account and data flows.

Confirm the chosen plans before launch. Set the Supabase global file limit to at least the workspace’s 20 MB limit and review storage and egress quotas. Check Railway usage pricing and Vercel’s eligibility rules for the intended public service. [Supabase billing](https://supabase.com/docs/guides/platform/billing-on-supabase) · [Storage limits](https://supabase.com/docs/guides/storage/uploads/file-limits) · [Railway pricing](https://docs.railway.com/reference/pricing/plans) · [Vercel Hobby plan](https://vercel.com/docs/plans/hobby)

## Supabase

1. Initialize local Supabase with `supabase init` if the checkout lacks `supabase/config.toml`. Run `supabase start` and `supabase test db` for local integration testing. Use `supabase status` to get the local service URL and credentials. Keep privileged keys out of frontend configuration. [Supabase CLI setup](https://supabase.com/docs/guides/local-development/cli/getting-started) · [Database tests](https://supabase.com/docs/guides/local-development/testing/overview)
2. For staging, link the dedicated project using `supabase link --project-ref <staging-project-ref>`. Review `supabase db push --dry-run` before `supabase db push`. The migration creates four ownership-scoped tables, narrowly grants access, and creates `thesis-checker-private`. It does not require enabling client writes or making the bucket public. [Data API grants](https://supabase.com/changelog/45329-breaking-change-tables-not-exposed-to-data-and-graphql-api-automatically) · [Storage buckets](https://supabase.com/docs/guides/storage/buckets/fundamentals)
3. Enable email/password signups and Confirm email. Set the Auth Site URL to the frontend origin and add the exact `<frontend-origin>/?auth=verify` and `<frontend-origin>/?auth=recovery` redirect URLs. Add local equivalents only to a development project. Keep the default PKCE-compatible email link templates and verify them with the target SMTP provider. Both flows use the browser where the request started. [Password-based Auth](https://supabase.com/docs/guides/auth/passwords)
4. Configure custom SMTP for public registration and recovery. Supabase’s built-in mail is restricted to project-team addresses and subject to strict rate limits. Set the Auth password minimum to 12 characters, enable CAPTCHA and abuse protection before public signup, and keep access-token expiry appropriate for private data. This client does not yet send CAPTCHA tokens. [SMTP setup](https://supabase.com/docs/guides/auth/auth-smtp) · [Production checklist](https://supabase.com/docs/guides/deployment/going-into-prod)

## Railway API

Deploy the source root as a Railway service using the root `Dockerfile`. Set `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SECRET_KEY`, and `APP_ORIGINS`. The latter is a comma-separated list of exact frontend origins. Railway supplies `PORT`. Use `/readyz` for deployment readiness and monitor `/healthz` plus `/readyz` after deploy. The latter verifies the database and a private bucket. Configure structured log alerting and request-rate protection at the hosting edge before public launch. [Railway Dockerfiles](https://docs.railway.com/builds/dockerfiles) · [Railway health checks](https://docs.railway.com/deployments/healthchecks)

Run a single API replica in staging. The API enforces per-process rate limits and concurrency caps. The database enforces the owner’s version and storage quotas independently of the API process. Use a shared limiter before relying on those request limits across replicas.

## Vercel frontend

To stage the optional account workspace on a separate deployment, override its build command with `npm run build:account`. Set `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, and `VITE_THESIS_API_URL` to the dedicated project and public HTTPS Railway service. Use the publishable key in the browser configuration. The account build restricts browser requests to the configured services. [Vite on Vercel](https://vercel.com/docs/frameworks/frontend/vite)

For local account mode, copy `.env.example` to `.env`, fill it using your local Supabase output, and set `APP_ORIGINS=http://localhost:5173` and `VITE_THESIS_API_URL=http://localhost:8080`. Start the API with `npm run start:api` and the frontend with `npm run dev -- --mode account`. Use the same host spelling for the browser and the redirect configuration.

## Staging acceptance checks

- Run `npm run lint`, `npm run typecheck`, `npm run typecheck:api`, `npm run test:api`, `npm run build`, and `npm run build:account` with configured public environment values. The Node tests verify parsing and API boundaries using fixtures. Run the separate PostgreSQL tests against a local Supabase instance.
- Register a new staging user, open the confirmation email in the requesting browser, sign out, and sign back in. Test password reset via the real mail workflow. Use Mailpit for local Supabase and your SMTP provider for hosted staging. [Testing Auth flows](https://supabase.com/docs/guides/auth/testing-auth-flows)
- Upload a readable PDF and DOCX, upload a revision, verify stored history after refresh, and download the original version. Check the application rejects an invalid archive and oversized upload. From a second account, try the first account’s document and version IDs through both the API and the Supabase Data API. Confirm private bucket objects are unavailable to browser credentials and download links expire.
- Trigger a failed upload and restart the API. Verify stale reservations are cleaned after their 30-minute expiry. Test deleting a document and an account and confirm the objects are removed from Storage. Inspect readiness and error logs for secret or document content exposure.

## Privacy and launch gates

Stored drafts remain private until a student deletes the document or account. A failed or interrupted upload can remain pending until its 30-minute expiry and cleanup. Live object deletion precedes database confirmation. Use a dedicated staging project, configure appropriate database and object-storage backup coverage, and document the retention and restore practices for those backups. The backup and deletion policy should reflect actual provider and plan behavior. [Supabase backups](https://supabase.com/docs/guides/platform/backups)

Before opening registration to students, identify the operator and privacy contact, publish terms and a notice describing processing, retention, rights requests, and providers, and review the launch against Philippine data privacy requirements. Review transparency, legitimate purpose, proportionality, retention, and security obligations with an appropriate reviewer. The code does not establish legal compliance. Uploaded files are sent to the project’s private storage and are not submitted to a search, academic, or plagiarism provider by this milestone. [Philippine Data Privacy Act](https://privacy.gov.ph/data-privacy-act/)
