export const categories = ['citation', 'redundancy', 'similarity', 'writing'] as const
export type Category = typeof categories[number]

export const categoryLabel: Record<Category, string> = {
  citation: 'Citations', redundancy: 'Redundancy', similarity: 'Similarity', writing: 'Writing',
}

interface Span { start: number; end: number }

export interface Finding extends Span {
  id: string
  category: Category
  severity: 'Review' | 'Suggestion' | 'Match'
  title: string
  detail: string
  source?: { name: string; excerpt: string }
}

export interface Source { name: string; text: string }

export interface Report {
  id: string
  name: string
  createdAt: string
  text: string
  wordCount: number
  citationsChecked: number
  hasReferences: boolean
  findings: Finding[]
  sources: string[]
  similarity: number | null
}

const referenceHeading = /^\s*(?:references|bibliography|works cited)\s*$/im
const yearPattern = /\b(?:18|19|20)\d{2}[a-z]?\b/gi
const firstAuthor = /^([\p{Lu}][\p{L}\p{M}'’.-]+(?:\s+(?:de|del|van|von|da|la)\s+[\p{Lu}][\p{L}\p{M}'’.-]+)?)/u
const authorName = String.raw`[\p{Lu}][\p{L}\p{M}'’.-]+`
const citationYear = String.raw`(?:18|19|20)\d{2}[a-z]?`
const narrativeCitation = new RegExp(String.raw`\b${authorName}(?:(?:\s+(?:and|&)\s+${authorName})|\s+et al\.)?\s*\((${citationYear}(?:\s*,\s*${citationYear})*)\)`, 'gu')
const numericCitation = /\[\d+(?:\s*[-–,]\s*\d+)*\]/g
const overlapSize = 8

function tokens(text: string, offset = 0) {
  return Array.from(text.matchAll(/[\p{L}\p{M}\p{N}]+(?:['’][\p{L}\p{M}]+)*/gu), (match) => ({
    word: match[0].toLowerCase().replaceAll('’', "'"),
    start: offset + match.index,
    end: offset + match.index + match[0].length,
  }))
}

function readCitations(body: string) {
  const citations: (Span & { keys: string[]; label: string })[] = []
  for (const match of body.matchAll(/\(([^()\n]{1,220})\)/g)) {
    const keys = match[1].split(';').flatMap((part) => {
      const entry = part.trim().replace(/^(?:see also|see|e\.g\.,)\s+/i, '')
      const author = firstAuthor.exec(entry)?.[1]
      const years = entry.match(yearPattern)
      return author && years && /,\s*(?:18|19|20)\d{2}/.test(entry)
        ? years.map((year) => `${author} ${year}`.toLowerCase()) : []
    })
    if (keys.length) citations.push({ start: match.index, end: match.index + match[0].length, keys, label: match[0] })
  }
  for (const match of body.matchAll(narrativeCitation)) {
    const author = firstAuthor.exec(match[0])?.[1]
    const years = match[1].match(yearPattern)
    if (author && years) citations.push({ start: match.index, end: match.index + match[0].length, keys: years.map((year) => `${author} ${year}`.toLowerCase()), label: match[0] })
  }
  return citations.sort((a, b) => a.start - b.start)
}

function eligibleTokens(body: string, exclusions: Span[]) {
  const groups: ReturnType<typeof tokens>[] = []
  let offset = 0
  for (const span of exclusions.sort((a, b) => a.start - b.start)) {
    if (span.start > offset) groups.push(tokens(body.slice(offset, span.start), offset))
    offset = Math.max(offset, span.end)
  }
  groups.push(tokens(body.slice(offset), offset))
  return groups
}

function compareSources(groups: ReturnType<typeof eligibleTokens>, sources: Source[]) {
  type SourceMatch = { source: Source; group: number; index: number; start: number; end: number }
  const sourcePhrases = new Map<string, SourceMatch>()
  let groupIndex = 0
  for (const source of sources) {
    const body = source.text.split(referenceHeading)[0]
    const segments = eligibleTokens(body, citationExclusions(body, readCitations(body)))
    for (const words of segments) {
      const group = groupIndex++
      for (let index = 0; index + overlapSize <= words.length; index++) {
        const phrase = words.slice(index, index + overlapSize).map(({ word }) => word).join(' ')
        if (!sourcePhrases.has(phrase)) sourcePhrases.set(phrase, { source, group, index, start: words[index].start, end: words[index + overlapSize - 1].end })
      }
    }
  }

  const matches: Omit<Finding, 'id'>[] = []
  let matchedWords = 0
  let eligibleWords = 0
  for (const words of groups) {
    eligibleWords += words.length
    let lastEnd = 0
    let previous: { finding: typeof matches[number]; sourceMatch: SourceMatch; draftIndex: number } | undefined
    for (let index = 0; index + overlapSize <= words.length; index++) {
      const phrase = words.slice(index, index + overlapSize).map(({ word }) => word).join(' ')
      const match = sourcePhrases.get(phrase)
      if (!match) continue
      const endIndex = index + overlapSize
      matchedWords += endIndex - Math.max(index, lastEnd)
      const end = words[endIndex - 1].end
      if (previous?.sourceMatch.group === match.group && match.index - previous.sourceMatch.index === index - previous.draftIndex && index < lastEnd) {
        previous.finding.end = end
        previous.finding.source = { name: match.source.name, excerpt: match.source.text.slice(previous.sourceMatch.start, match.end) }
      } else {
        const finding: typeof matches[number] = {
          start: words[index].start, end, category: 'similarity', severity: 'Match',
          title: 'Exact wording overlap', detail: 'Eight or more consecutive words appear in a comparison source. Review how the wording is quoted, cited, or paraphrased.',
          source: { name: match.source.name, excerpt: match.source.text.slice(match.start, match.end) },
        }
        matches.push(finding)
        previous = { finding, sourceMatch: match, draftIndex: index }
      }
      lastEnd = endIndex
    }
  }
  return { matches, similarity: eligibleWords ? Math.round(matchedWords / eligibleWords * 1000) / 10 : null }
}

function citationExclusions(body: string, citations: Span[]) {
  return [...citations, ...Array.from(body.matchAll(numericCitation), (match) => ({ start: match.index, end: match.index + match[0].length }))]
}

export function analyzeDocument(name: string, text: string, sources: Source[]): Report {
  const heading = referenceHeading.exec(text)
  const body = heading ? text.slice(0, heading.index) : text
  const references = heading ? text.slice(heading.index + heading[0].length) : ''
  const referenceKeys = new Set(Array.from(references.matchAll(/^\s*([^\n]+?)\s*\(\s*((?:18|19|20)\d{2}[a-z]?)\b/gm), (match) => {
    const author = firstAuthor.exec(match[1].trim())?.[1]
    return `${author} ${match[2]}`.toLowerCase()
  }))
  const citations = readCitations(body)
  const findings: Omit<Finding, 'id'>[] = []

  for (const { start, end, keys, label } of citations) {
    const missing = [...new Set(keys.filter((key) => !referenceKeys.has(key)))]
    if (!missing.length) continue
    findings.push({ start, end, category: 'citation', severity: 'Review', title: 'Check reference entry', detail: `The checker could not link ${label} to a matching author and year in the reference list. Review the reference entry and its formatting.` })
  }

  const writingRules = [
    { category: 'redundancy', pattern: /\b([\p{L}]{2,})\s+\1\b/giu, title: 'Repeated word', detail: 'Check whether the second occurrence is needed in this sentence.' },
    { category: 'redundancy', pattern: /\b(?:due to the fact that|in order to|at this point in time|past history|future plans|end result|final outcome|repeat again)\b/gi, title: 'Possible wordiness', detail: 'Consider a shorter expression if it preserves your meaning.' },
    { category: 'writing', pattern: /(?<=\p{L})[\t ]+[,;:!?](?=\s|$)/gu, title: 'Space before punctuation', detail: 'Check whether the punctuation should sit directly next to the preceding word.' },
    { category: 'writing', pattern: /(?<=\p{L})[\t ]{2,}(?=\p{L})/gu, title: 'Extra spacing', detail: 'Check the original document for extra spaces between words.' },
  ] as const

  for (const { category, pattern, title, detail } of writingRules) {
    for (const match of body.matchAll(pattern)) {
      const start = match.index
      const end = start + match[0].length
      findings.push({ start, end, category, severity: 'Suggestion', title, detail })
    }
  }

  const comparison = sources.length ? compareSources(eligibleTokens(body, citationExclusions(body, citations)), sources) : null
  if (comparison) findings.push(...comparison.matches)

  return {
    id: crypto.randomUUID?.() ?? Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) => byte.toString(16).padStart(2, '0')).join(''),
    name, text, createdAt: new Date().toISOString(), wordCount: tokens(text).length,
    citationsChecked: citations.length, hasReferences: Boolean(heading), sources: sources.map((source) => source.name),
    similarity: comparison?.similarity ?? null,
    findings: findings.sort((a, b) => a.start - b.start).map((finding, index) => ({ ...finding, id: `finding-${index + 1}` })),
  }
}
