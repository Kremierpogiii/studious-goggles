import { ArrowLeft, ArrowRight, CircleAlert, Download, FileText, Fingerprint, Info, Printer, Quote, ScanLine, ShieldCheck, Sparkles, UploadCloud, Workflow, X } from 'lucide-react'
import { useEffect, useMemo, useRef, useState } from 'react'
import type { DragEvent, FormEvent, ReactNode } from 'react'
import { categories, categoryLabel } from './analysis'
import type { Category, Finding, Report, Source } from './analysis'
import { analyzeInWorker, downloadReport, extractDocument, maxSources, validateFile } from './documents'
import { links, PageTitle, reportLink } from './ui'

const acceptedFiles = '.pdf,.docx'
const categoryIcons = { citation: Quote, redundancy: Workflow, similarity: Fingerprint, writing: Sparkles }

function FilePreview({ file, disabled, onRemove }: { file: File; disabled: boolean; onRemove: () => void }) {
  const size = file.size >= 1024 * 1024 ? `${(file.size / (1024 * 1024)).toFixed(1)} MB` : `${Math.max(1, Math.round(file.size / 1024))} KB`
  return <div className="file-preview"><span className="tile-icon tone-mint"><FileText size={17} /></span><div><strong>{file.name}</strong><span>{file.name.split('.').pop()?.toUpperCase()} · {size}</span></div><button type="button" disabled={disabled} className="icon-button" onClick={onRemove} aria-label={`Remove ${file.name}`}><X size={17} /></button></div>
}

export function UploadPage({ draft, disabled, onComplete }: { draft?: Report; disabled: boolean; onComplete: (report: Report, openReport: boolean) => void }) {
  const [file, setFile] = useState<File>()
  const [sources, setSources] = useState<File[]>([])
  const [dragging, setDragging] = useState(false)
  const [progress, setProgress] = useState<{ label: string; value: number }>()
  const [error, setError] = useState('')
  const mainInput = useRef<HTMLInputElement>(null)
  const sourceInput = useRef<HTMLInputElement>(null)
  const active = useRef(false)
  const mounted = useRef(false)
  const canAnalyze = draft ? sources.length > 0 : Boolean(file)

  useEffect(() => {
    mounted.current = true
    return () => { mounted.current = false }
  }, [])

  function selectDraft(files: File[]) {
    if (!files.length || active.current) return
    const validation = files.length > 1 ? 'Choose one draft at a time. Comparison files can be added separately.' : validateFile(files[0])
    setError(validation)
    if (validation) return
    setFile(files[0])
  }

  function selectSources(files: File[]) {
    if (!files.length || active.current) return
    const validation = files.map(validateFile).find(Boolean)
    if (validation) { setError(validation); return }
    const combined = [...sources]
    for (const candidate of files) {
      if (!combined.some((source) => source.name === candidate.name && source.size === candidate.size && source.lastModified === candidate.lastModified)) combined.push(candidate)
    }
    if (combined.length > maxSources) { setError(`Add up to ${maxSources} comparison files.`); return }
    setSources(combined)
    setError('')
  }

  function handleDrop(event: DragEvent<HTMLElement>) {
    event.preventDefault()
    setDragging(false)
    selectDraft(Array.from(event.dataTransfer.files))
  }

  async function analyze(event: FormEvent) {
    event.preventDefault()
    if (!canAnalyze || active.current || disabled) return
    if (file && sources.some((source) => source.name === file.name && source.size === file.size && source.lastModified === file.lastModified)) {
      setError('Remove the draft from the comparison files before running analysis.')
      return
    }
    active.current = true
    setError('')
    const files = file ? [file, ...sources] : sources
    const extracted: Source[] = draft ? [{ name: draft.name, text: draft.text }] : []
    let currentFile = ''
    try {
      for (const [index, document] of files.entries()) {
        currentFile = document.name
        const label = `Reading ${document.name}`
        setProgress({ label, value: index / files.length * 100 })
        const text = await extractDocument(document, (fraction) => setProgress({ label, value: (index + fraction) / files.length * 100 }))
        if (draft && document.name === draft.name && text === draft.text) throw new Error('Choose a separate source file to compare against this draft.')
        extracted.push({ name: document.name, text })
      }
      setProgress({ label: 'Checking extracted text…', value: 100 })
      currentFile = extracted[0].name
      const report = await analyzeInWorker(extracted[0], extracted.slice(1))
      onComplete(draft ? { ...report, id: draft.id, createdAt: draft.createdAt } : report, mounted.current)
    } catch (cause) {
      const detail = cause instanceof Error ? cause.message : 'The file could not be processed.'
      setError(`${currentFile} — ${detail}`)
    } finally {
      setProgress(undefined)
      active.current = false
    }
  }

  return <>
    {draft && <a href={reportLink(draft.id, 'similarity')} className="text-link report-back"><ArrowLeft size={16} /> Back to report</a>}
    {draft ? <PageTitle label="SOURCE COMPARISON" title="Compare sources" description="Compare your saved draft with papers or other source files you provide." />
      : <PageTitle label="DOCUMENT ANALYSIS" title="Analyze a document" description="Add your thesis or research draft to review citations, repeated wording, and source overlap." />}
    <div className="upload-layout">
      <form className="panel upload-form" onSubmit={analyze}>
        <div className="form-section-heading"><span className="step-number">01</span><div><h2>Research document</h2><p>{draft ? 'Ready to compare using the text in this report.' : 'Choose the draft you want to review.'}</p></div></div>
        {draft ? <div className="file-preview"><span className="tile-icon tone-mint"><FileText size={17} /></span><div><strong>{draft.name}</strong><span>{draft.wordCount.toLocaleString()} words</span></div></div> : <>
          <input ref={mainInput} type="file" accept={acceptedFiles} hidden onChange={(event) => { selectDraft(Array.from(event.target.files ?? [])); event.target.value = '' }} />
          <button type="button" className={`dropzone ${dragging ? 'dropzone-active' : ''}`} disabled={Boolean(progress)} onClick={() => mainInput.current?.click()} onDragOver={(event) => { event.preventDefault(); if (!active.current) setDragging(true) }} onDragLeave={() => setDragging(false)} onDrop={handleDrop}>
            <span className="empty-icon"><UploadCloud size={25} strokeWidth={1.7} /></span><strong>{file ? 'Drop a replacement or browse' : 'Drop your document here'}</strong><span><span className="dropzone-link">Browse files</span> or drag and drop</span><small>PDF or DOCX · Up to 20 MB</small>
          </button>
          {file && <FilePreview file={file} disabled={Boolean(progress)} onRemove={() => { setFile(undefined); setError('') }} />}
        </>}
        <div className="form-section-heading comparison-heading"><span className="step-number">02</span><div><h2>Comparison sources {!draft && <small>Optional</small>}</h2><p>{draft ? `Add 1 to ${maxSources} PDF or DOCX source files.` : `Add up to ${maxSources} PDF or DOCX files to run the similarity check.`}</p></div></div>
        <input ref={sourceInput} type="file" accept={acceptedFiles} multiple hidden onChange={(event) => { selectSources(Array.from(event.target.files ?? [])); event.target.value = '' }} />
        <button className="button button-secondary" type="button" disabled={Boolean(progress) || sources.length >= maxSources} onClick={() => sourceInput.current?.click()}><FileText size={16} /> Add comparison files</button>
        {sources.map((source) => <FilePreview key={`${source.name}-${source.size}-${source.lastModified}`} file={source} disabled={Boolean(progress)} onRemove={() => { setSources(sources.filter((entry) => entry !== source)); setError('') }} />)}
        {error && <p className="notice notice-error" role="alert"><CircleAlert size={17} /><span>{error}</span></p>}
        {progress && <div className="upload-progress" role="status"><label htmlFor="document-progress">{progress.label}</label><progress id="document-progress" max={100} value={progress.value}>{Math.round(progress.value)}%</progress></div>}
        <div className="upload-actions"><button className="button button-primary" type="submit" disabled={!canAnalyze || Boolean(progress) || disabled}><ScanLine size={17} /> {progress ? 'Analyzing…' : draft ? 'Run similarity check' : 'Run analysis'} <ArrowRight size={16} /></button><span><ShieldCheck size={15} /> Processed on this device</span></div>
      </form>
      <aside className="panel analysis-guide"><span className="tile-icon tone-mint"><Info size={18} /></span><h2>What gets checked</h2>
        <ul><li><Quote size={17} /><div><strong>Citations</strong><p>Author–date citations compared with the reference list.</p></div></li><li><Workflow size={17} /><div><strong>Redundancy and writing</strong><p>Repeated wording and basic spacing and punctuation checks.</p></div></li><li><Fingerprint size={17} /><div><strong>Source overlap</strong><p>Exact sequences of eight or more words shared with supplied comparison files.</p></div></li></ul>
        <p className="guide-note">Use a PDF with selectable text. Scanned pages and images need text recognition before analysis.</p>
      </aside>
    </div>
  </>
}

function HighlightedText({ text, findings, selected }: { text: string; findings: Finding[]; selected: string | undefined }) {
  const parts: ReactNode[] = []
  const focused = findings.find((finding) => finding.id === selected)
  let cursor = 0
  for (const finding of findings) {
    if (finding.start < cursor || (focused && finding !== focused && finding.start < focused.end && finding.end > focused.start)) continue
    parts.push(text.slice(cursor, finding.start))
    parts.push(<mark key={finding.id} id={finding.id} className={`mark-${finding.category} ${selected === finding.id ? 'mark-current' : ''}`}>{text.slice(finding.start, finding.end)}</mark>)
    cursor = finding.end
  }
  parts.push(text.slice(cursor))
  return parts
}

export function ReviewReport({ report, initialCategory }: { report: Report; initialCategory?: Category }) {
  const similarityPending = report.sources.length === 0
  const [category, setCategory] = useState<Category>(initialCategory ?? report.findings[0]?.category ?? (similarityPending ? 'similarity' : 'citation'))
  const [selected, setSelected] = useState<string>()
  const [visible, setVisible] = useState(24)
  const grouped = useMemo(() => {
    const groups: Record<Category, Finding[]> = { citation: [], redundancy: [], similarity: [], writing: [] }
    for (const finding of report.findings) groups[finding.category].push(finding)
    return groups
  }, [report])
  const findings = grouped[category]
  useEffect(() => {
    if (selected) document.getElementById(selected)?.scrollIntoView({ block: 'center' })
  }, [selected])

  const context = {
    citation: `${report.citationsChecked} author–date citation${report.citationsChecked === 1 ? '' : 's'} recognized. ${report.hasReferences ? 'A reference section was found.' : 'No reference section heading was recognized.'}`,
    redundancy: 'Review each suggestion in context before changing your wording.',
    similarity: `${report.similarity === null ? 'Overlap unavailable' : `${report.similarity}% exact wording overlap`} across ${report.sources.length} comparison file${report.sources.length === 1 ? '' : 's'}.`,
    writing: 'Basic checks for spacing and punctuation in the extracted text.',
  }
  const empty = {
    citation: report.citationsChecked ? 'No citation issues were flagged by the supported checks.' : 'This check looks for author–date citations such as (Santos, 2024).',
    redundancy: 'No redundancy suggestions were flagged.',
    similarity: report.similarity === null ? 'The draft has no eligible text to compare after citations and references were excluded.' : 'No exact wording matches were found in the supplied files.',
    writing: 'No spacing or punctuation issues were flagged.',
  }

  return <>
    <a href={links.reports} className="text-link report-back"><ArrowLeft size={16} /> All reports</a>
    <PageTitle label="DOCUMENT REPORT" title={report.name} description={`${report.wordCount.toLocaleString()} words · ${report.findings.length.toLocaleString()} findings · ${new Date(report.createdAt).toLocaleDateString()}`} action={<div className="review-actions"><button className="button button-secondary" onClick={() => window.print()} type="button"><Printer size={16} /> Print view</button><button className="button button-primary" onClick={() => downloadReport(report)} type="button"><Download size={16} /> Export report</button></div>} />
    <div className="review-grid">
      <section className="panel review-document" aria-labelledby="document-heading"><div className="panel-heading"><div><h2 id="document-heading">Document viewer</h2><p>Extracted text with findings for the selected check.</p></div><FileText size={18} className="muted" /></div><div className="document-paper" tabIndex={0} aria-label="Extracted document text"><HighlightedText text={report.text} findings={findings} selected={selected} /></div></section>
      <section className="panel review-findings" aria-labelledby="findings-heading">
        <div className="panel-heading"><div><h2 id="findings-heading">Findings</h2><p>Choose a check to review its passages.</p></div></div>
        <div className="category-controls" role="group" aria-label="Check category">
          {categories.map((key) => {
            const Icon = categoryIcons[key]
            const missingSimilarity = key === 'similarity' && report.similarity === null
            return <button className="category-button" aria-pressed={category === key} aria-label={missingSimilarity ? `Similarity, ${similarityPending ? 'not checked' : 'unavailable'}` : undefined} key={key} type="button" onClick={() => { setCategory(key); setSelected(undefined); setVisible(24) }}><Icon size={15} /> {categoryLabel[key]} <span>{missingSimilarity ? '—' : grouped[key].length}</span></button>
          })}
        </div>
        {category === 'similarity' && similarityPending ? <div className="findings-content">
          <div className="finding-empty comparison-empty"><Info size={17} /><div><h3>Similarity not checked</h3><p>Add PDF or DOCX source files to compare against this draft.</p></div></div>
          <a href={reportLink(report.id, 'compare')} className="button button-primary compare-action"><FileText size={16} /> Add comparison files <ArrowRight size={16} /></a>
        </div> : <div className="findings-content"><p className="finding-context">{context[category]}</p>
          {category === 'similarity' && report.sources.length > 0 && <details className="source-list"><summary>Comparison files</summary><ul>{report.sources.map((source, index) => <li key={`${source}-${index}`}>{source}</li>)}</ul></details>}
          {!findings.length ? <p className="finding-empty"><Info size={17} />{empty[category]}</p> : <ol className="finding-list">
            {findings.slice(0, visible).map((finding) => <li key={finding.id}><button type="button" className="finding-card" aria-pressed={selected === finding.id} onClick={() => {
              if (selected === finding.id) document.getElementById(finding.id)?.scrollIntoView({ block: 'center' })
              else setSelected(finding.id)
            }}><span className={`severity severity-${finding.severity.toLowerCase()}`}>{finding.severity}</span><strong>{finding.title}</strong><span className="finding-detail">{finding.detail}</span>{finding.source && <span className="finding-source"><FileText size={14} />{finding.source.name}<span>“{finding.source.excerpt}”</span></span>}<span className="finding-jump">Show passage <ArrowRight size={14} /></span></button></li>)}
          </ol>}
          {visible < findings.length && <button className="button button-secondary" type="button" onClick={() => setVisible(visible + 24)}>Show more findings</button>}
        </div>}
      </section>
    </div>
  </>
}
