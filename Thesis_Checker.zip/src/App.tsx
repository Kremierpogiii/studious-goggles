import { ArrowRight, BookOpen, CircleHelp, FileSearch, Files, LayoutDashboard, Menu, PanelLeftClose, PanelLeftOpen, Search, Settings2, ShieldCheck, X } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import type { Report } from './analysis'
import { readReports, saveReport, upsertReport } from './documents'
import { ReviewReport, UploadPage } from './Review'
import { Brand, brandName, links, PageTitle, reportLink } from './ui'
import { Dashboard, Landing, readPreferences, Reports, Settings } from './Workspace'

const workspaceLinks = [
  { name: 'Dashboard', href: links.dashboard, icon: LayoutDashboard },
  { name: 'Analyze document', href: links.upload, icon: FileSearch },
  { name: 'Reports', href: links.reports, icon: Files },
]
const utilityLinks = [
  { name: 'Settings', href: links.settings, icon: Settings2 },
  { name: 'About the checker', href: links.about, icon: CircleHelp },
]

function getPath() { return window.location.hash.slice(1) || '/' }

function Navigation({ path, onNavigate }: { path: string; onNavigate?: () => void }) {
  return <nav className="sidebar-nav" aria-label="Workspace navigation">
    {[{ label: 'WORKSPACE', entries: workspaceLinks }, { label: 'PREFERENCES', entries: utilityLinks }].map(({ label, entries }) => <div className="navigation-group" key={label}>
      <p>{label}</p>
      {entries.map(({ name, href, icon: Icon }) => {
        const current = `#${path}` === href || href === links.reports && path.startsWith('/report/')
        return <a key={href} href={href} title={name} aria-current={current ? 'page' : undefined} onClick={onNavigate}><Icon size={18} strokeWidth={1.8} /><span>{name}</span></a>
      })}
    </div>)}
  </nav>
}

function SidebarFoot() {
  return <div className="sidebar-foot"><div className="privacy-card"><span className="privacy-icon"><ShieldCheck size={17} /></span><div><strong>Private workspace</strong><p>Analysis stays on this device.</p></div></div><p className="sidebar-edition"><span /> EMERALD INTELLIGENCE</p></div>
}

export default function App() {
  const [path, setPath] = useState(getPath)
  const [preferences, setPreferences] = useState(readPreferences)
  const [reports, setReports] = useState<Report[]>([])
  const [loading, setLoading] = useState(true)
  const [storageError, setStorageError] = useState('')
  const [collapsed, setCollapsed] = useState(false)
  const [query, setQuery] = useState('')
  const search = useRef<HTMLDialogElement>(null)
  const searchInput = useRef<HTMLInputElement>(null)
  const mobileNav = useRef<HTMLDialogElement>(null)
  const changedRoute = useRef(false)

  useEffect(() => {
    let mounted = true
    readReports().then((saved) => { if (mounted) setReports(saved) }).catch(() => {
      if (mounted) setStorageError('Report history could not be loaded from this browser.')
    }).finally(() => { if (mounted) setLoading(false) })
    return () => { mounted = false }
  }, [])

  useEffect(() => {
    function route() { changedRoute.current = true; setPath(getPath()) }
    function keyboard(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k' && search.current && !mobileNav.current?.open) {
        event.preventDefault()
        if (!search.current.open) openSearch()
      }
    }
    window.addEventListener('hashchange', route)
    window.addEventListener('keydown', keyboard)
    return () => { window.removeEventListener('hashchange', route); window.removeEventListener('keydown', keyboard) }
  }, [])

  const landing = path === '/about' || path === '/about/features' || path === '/about/how-it-works'
  const reportRoute = /^\/report\/([^/]+)(?:\/(compare|similarity))?$/.exec(path)
  const report = reportRoute ? reports.find(({ id }) => id === reportRoute[1]) : undefined
  const reportView = reportRoute?.[2]
  const activePage = report ? (reportView === 'compare' ? 'Compare sources' : 'Document report') : path === '/settings' ? 'Settings' : path === '/upload' ? 'Analyze document' : path === '/reports' ? 'Reports' : 'Dashboard'

  useEffect(() => {
    document.title = `${landing ? 'About' : activePage} · ${brandName}`
  }, [activePage, landing])

  useEffect(() => {
    search.current?.close()
    mobileNav.current?.close()
    const section = path.startsWith('/about/') ? document.getElementById(path.slice('/about/'.length)) : undefined
    if (section) { section.scrollIntoView({ block: 'start' }); return }
    if (!changedRoute.current) return
    window.scrollTo(0, 0)
    document.getElementById('main-content')?.focus({ preventScroll: true })
  }, [path])

  function openSearch() {
    search.current?.showModal()
    searchInput.current?.focus()
  }

  function complete(result: Report, openReport: boolean) {
    setReports((previous) => upsertReport(previous, result))
    saveReport(result).catch(() => setStorageError('This report is open for this session. Browser storage could not save it for later.'))
    if (openReport && getPath() === path) window.location.hash = reportLink(result.id, reportView === 'compare' ? 'similarity' : undefined)
  }

  const matchingReports = reports.filter(({ name }) => name.toLowerCase().includes(query.trim().toLowerCase())).slice(0, 8)
  const skipLink = <a className="skip-link" href="#main-content" onClick={(event) => { event.preventDefault(); document.getElementById('main-content')?.focus() }}>Skip to main content</a>

  return <div className={`${preferences.compact ? 'compact-tables' : ''} ${preferences.reduceMotion ? 'reduced-motion' : ''}`}>
    {skipLink}
    {landing ? <Landing /> : <div className={`app-shell ${collapsed ? 'sidebar-collapsed' : ''}`}>
      <aside className="sidebar">
        <div className="sidebar-top"><Brand /><button className="icon-button collapse-button" type="button" aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'} aria-expanded={!collapsed} onClick={() => setCollapsed(!collapsed)}>{collapsed ? <PanelLeftOpen size={17} /> : <PanelLeftClose size={17} />}</button></div>
        <Navigation path={path} /><SidebarFoot />
      </aside>
      <div className="workspace">
        <header className="topbar">
          <div className="breadcrumb"><button className="icon-button mobile-menu-button" type="button" aria-label="Open navigation" onClick={() => mobileNav.current?.showModal()}><Menu size={20} /></button><span className="breadcrumb-icon"><BookOpen size={16} /></span><span className="breadcrumb-root">Workspace</span><span className="breadcrumb-divider">/</span><span className="breadcrumb-current">{activePage}</span></div>
          <button className="search-trigger" type="button" aria-label="Search reports" onClick={openSearch}><Search size={17} /><span>Search reports</span><kbd>Ctrl K</kbd></button>
        </header>
        <main id="main-content" className="main-content" tabIndex={-1}>
          {storageError && <p className="notice notice-error" role="status"><ShieldCheck size={16} />{storageError}</p>}
          <div className="page-content" key={path}>
            {path === '/' ? <Dashboard reports={reports} loading={loading} />
              : path === '/upload' ? <UploadPage disabled={loading} onComplete={complete} />
              : path === '/reports' ? <Reports reports={reports} loading={loading} />
              : path === '/settings' ? <Settings preferences={preferences} onSave={setPreferences} />
              : report && reportView === 'compare' ? <UploadPage draft={report} disabled={loading} onComplete={complete} />
              : report ? <ReviewReport report={report} initialCategory={reportView === 'similarity' ? 'similarity' : undefined} />
              : loading && path.startsWith('/report/') ? <p className="panel-message" role="status">Loading report…</p>
              : <PageTitle label="WORKSPACE" title={path.startsWith('/report/') ? 'Report unavailable' : 'Page unavailable'} description="Return to the workspace or open a report saved in this browser." action={<a className="button button-primary" href={links.dashboard}>Back to dashboard <ArrowRight size={16} /></a>} />}
          </div>
        </main>
        <footer className="workspace-footer"><span>{brandName}</span><a href={links.about}>About this workspace <ArrowRight size={13} /></a></footer>
      </div>
      <dialog className="search-dialog panel" ref={search} aria-labelledby="search-title" onClose={() => setQuery('')}>
        <div className="dialog-heading"><h2 id="search-title">Search reports</h2><button className="icon-button" type="button" aria-label="Close search" onClick={() => search.current?.close()}><X size={19} /></button></div>
        <label className="input-with-icon"><Search size={17} /><span className="sr-only">Document name</span><input ref={searchInput} value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search by document name…" /></label>
        {matchingReports.length ? <ul className="search-results">{matchingReports.map(({ id, name }) => <li key={id}><a href={reportLink(id)} onClick={() => search.current?.close()}><Files size={16} /><span>{name}</span><ArrowRight size={15} /></a></li>)}</ul> : <p className="search-empty">{loading ? 'Loading local reports…' : query ? 'No reports match your search.' : 'Reports will appear after your first analysis.'}</p>}
      </dialog>
      <dialog className="mobile-nav" ref={mobileNav} aria-label="Workspace navigation"><div className="sidebar-top"><Brand /><button type="button" className="icon-button" aria-label="Close navigation" onClick={() => mobileNav.current?.close()}><X size={20} /></button></div><Navigation path={path} onNavigate={() => mobileNav.current?.close()} /><SidebarFoot /></dialog>
    </div>}
  </div>
}
