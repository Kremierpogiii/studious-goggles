import { lazy, StrictMode, Suspense } from 'react'
import { createRoot } from 'react-dom/client'
import '@fontsource/inter/latin-400.css'
import '@fontsource/inter/latin-500.css'
import '@fontsource/inter/latin-600.css'
import '@fontsource/inter/latin-700.css'
import App from './App'
import './styles.css'

const Account = import.meta.env.VITE_WORKSPACE_MODE === 'account' ? lazy(() => import('./Account')) : null

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    {Account
      ? <Suspense fallback={<main className="main-content" role="status">Loading student workspace…</main>}><Account /></Suspense>
      : <App />}
  </StrictMode>,
)
