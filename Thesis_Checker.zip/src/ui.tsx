import { ArrowRight, BookOpen, FileSearch, FileText, ScanLine, ShieldCheck } from 'lucide-react'
import type { ReactNode } from 'react'
import type { Report } from './analysis'

export const links = {
  dashboard: '#/', upload: '#/upload', reports: '#/reports', settings: '#/settings', about: '#/about',
}
export const reportLink = (id: string, view?: 'compare' | 'similarity') => `#/report/${id}${view ? `/${view}` : ''}`
const brandTitle = 'THESIS CHECKER'
const brandByline = 'NI JEAN KO'
export const brandName = `${brandTitle} ${brandByline}`

export function Brand() {
  return <a className="brand" href={links.dashboard} aria-label={`${brandName} dashboard`}>
    <span className="brand-mark"><BookOpen size={20} strokeWidth={1.9} /></span>
    <span>{brandTitle} <span className="brand-accent">{brandByline}</span><small>RESEARCH WORKSPACE</small></span>
  </a>
}

export function PageTitle({ label, title, description, action }: { label: string; title: string; description: string; action?: ReactNode }) {
  return <div className="page-heading">
    <div><p className="eyebrow"><span />{label}</p><h1>{title}</h1><p className="page-description">{description}</p></div>
    {action}
  </div>
}

export function DocumentArt() {
  return <svg className="document-art" viewBox="0 0 456 280" fill="none" aria-hidden="true">
    <defs>
      <linearGradient id="art-paper" x1="174" y1="52" x2="300" y2="235" gradientUnits="userSpaceOnUse"><stop stopColor="#D1FAE5"/><stop offset="1" stopColor="#6EE7B7"/></linearGradient>
      <linearGradient id="art-base" x1="250" y1="52" x2="360" y2="244" gradientUnits="userSpaceOnUse"><stop stopColor="#34D399" stopOpacity=".28"/><stop offset="1" stopColor="#10B981" stopOpacity=".02"/></linearGradient>
      <pattern id="art-grid" width="24" height="24" patternUnits="userSpaceOnUse"><path d="M24 0H0v24" stroke="#A7F3D0" strokeOpacity=".085"/></pattern>
      <radialGradient id="art-grid-fade"><stop offset=".38" stopColor="white"/><stop offset="1" stopColor="black"/></radialGradient>
      <mask id="art-mask"><ellipse cx="247" cy="140" rx="217" ry="143" fill="url(#art-grid-fade)"/></mask>
    </defs>
    <path d="M30 0h426v280H30z" fill="url(#art-grid)" mask="url(#art-mask)"/>
    <g stroke="#A7F3D0" strokeOpacity=".22"><ellipse cx="253" cy="142" rx="150" ry="108" transform="rotate(-19 253 142)" strokeDasharray="3 6"/><ellipse cx="253" cy="142" rx="183" ry="80" transform="rotate(-19 253 142)"/><path d="M86 165h22m-11-11v22m293-92h20m-10-10v20M147 55h12m-6-6v12m201 164h13m-6-6v12"/></g>
    <g transform="rotate(11 265 143)"><rect x="213" y="56" width="126" height="177" rx="15" fill="url(#art-base)" stroke="#6EE7B7" strokeOpacity=".52"/><path d="M237 89h45m-45 15h71m-71 15h65m-65 15h71m-71 15h47m-47 15h64" stroke="#6EE7B7" strokeOpacity=".24" strokeWidth="3" strokeLinecap="round"/></g>
    <g transform="rotate(-10 245 142)">
      <rect x="177" y="53" width="131" height="181" rx="15" fill="#062F25" transform="translate(0 8)" opacity=".35"/>
      <path d="M192 53h83l33 33v133a15 15 0 0 1-15 15H192a15 15 0 0 1-15-15V68a15 15 0 0 1 15-15Z" fill="url(#art-paper)"/>
      <path d="M275 54v21a11 11 0 0 0 11 11h21" fill="#34D399" opacity=".75"/>
      <rect x="196" y="79" width="26" height="25" rx="6" fill="#064E3B"/><path d="M203 85c4-1 6 0 6 2 1-2 3-3 7-2v12c-3-1-6 0-7 2-1-2-4-3-6-2V85Zm6 2v11" stroke="#D1FAE5" strokeWidth="1.3" strokeLinejoin="round"/>
      <path d="M196 121h65" stroke="#064E3B" strokeWidth="4" strokeLinecap="round"/>
      <path d="M196 137h93m-93 13h80m-80 27h89m-89 13h68m-68 13h79" stroke="#064E3B" strokeOpacity=".36" strokeWidth="3" strokeLinecap="round"/>
      <rect x="193" y="156" width="100" height="11" rx="4" fill="#059669" opacity=".28"/><path d="M198 161.5h88" stroke="#064E3B" strokeOpacity=".6" strokeWidth="2.5" strokeLinecap="round"/>
    </g>
    <g transform="translate(320 161)"><rect width="60" height="60" rx="16" fill="#0A4434" stroke="#6EE7B7" strokeOpacity=".64"/><rect x="4" y="4" width="52" height="52" rx="12" stroke="#A7F3D0" strokeOpacity=".15"/><path d="M30 15c5 4 10 5 13 6v10c0 8-6 13-13 16-7-3-13-8-13-16V21c3-1 8-2 13-6Z" stroke="#A7F3D0" strokeWidth="2" strokeLinejoin="round"/><path d="m24 30 4 4 8-9" stroke="#A7F3D0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></g>
    <g transform="translate(114 87)"><rect width="42" height="42" rx="12" fill="#0A4434" stroke="#6EE7B7" strokeOpacity=".48"/><path d="M13 17v-4h4m8 0h4v4m0 8v4h-4m-8 0h-4v-4m2-4h12" stroke="#A7F3D0" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></g>
    <circle cx="115" cy="183" r="3" fill="#6EE7B7"/><circle cx="367" cy="59" r="3" fill="#6EE7B7" fillOpacity=".75"/><circle cx="381" cy="114" r="2" fill="#A7F3D0"/><circle cx="165" cy="235" r="2" fill="#A7F3D0"/>
  </svg>
}

export function Hero({ landing = false }: { landing?: boolean }) {
  return <section className={`hero ${landing ? 'hero-landing' : ''}`} aria-label="Document analysis">
    <div className="hero-copy">
      <p className="hero-kicker"><ScanLine size={14} /> EMERALD INTELLIGENCE</p>
      {landing ? <h1>Review your research<br />with <em>confidence.</em></h1> : <h2>Good research deserves<br /><em>a closer look.</em></h2>}
      <p>Review citations, refine your writing, and check for matching wording in one focused workspace.</p>
      <a className="button button-bright" href={links.upload}>Analyze a document <ArrowRight size={17} /></a>
    </div>
    <DocumentArt />
    <div className="hero-private"><ShieldCheck size={14} /> Private, on-device analysis</div>
  </section>
}

export function EmptyReports({ compact = false }: { compact?: boolean }) {
  return <div className={`empty-state ${compact ? 'empty-compact' : ''}`}>
    <span className="empty-icon"><FileSearch size={23} strokeWidth={1.6} /></span>
    <h3>No reports yet</h3>
    <p>Analyze a thesis or research draft to see your first report here.</p>
    <a className="text-link" href={links.upload}>Upload a document <ArrowRight size={15} /></a>
  </div>
}

export function ReportTable({ reports }: { reports: Report[] }) {
  return <div className="table-wrap"><table><thead><tr><th scope="col">Document</th><th scope="col">Analyzed</th><th scope="col">Findings</th><th scope="col">Overlap</th><th scope="col"><span className="sr-only">Open report</span></th></tr></thead><tbody>
    {reports.map((report) => <tr key={report.id}>
      <th scope="row"><span className="table-name"><FileText size={17} /><a href={reportLink(report.id)}>{report.name}</a></span></th>
      <td>{new Date(report.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</td>
      <td>{report.findings.length.toLocaleString()}</td>
      <td>{report.similarity === null ? <span aria-label="No source comparison">—</span> : `${report.similarity}%`}</td>
      <td><a className="icon-button table-open" href={reportLink(report.id)} aria-label={`Open ${report.name}`}><ArrowRight size={16} /></a></td>
    </tr>)}
  </tbody></table></div>
}
