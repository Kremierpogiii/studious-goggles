import { analyzeDocument } from './analysis'
import type { Report, Source } from './analysis'

export type AnalysisResponse = { report: Report } | { error: string }

self.onmessage = (event: MessageEvent<{ draft: Source; sources: Source[] }>) => {
  try {
    const { draft, sources } = event.data
    self.postMessage({ report: analyzeDocument(draft.name, draft.text, sources) } satisfies AnalysisResponse)
  } catch (error) {
    self.postMessage({ error: error instanceof Error ? error.message : 'The extracted text could not be analyzed.' } satisfies AnalysisResponse)
  }
}
