import { ArrowRight, CircleAlert, FileText, Files, History, LockKeyhole, LogOut, RefreshCw, ShieldCheck, Upload, UploadCloud } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import type { FormEvent } from 'react'
import type { Session, SupabaseClient } from '@supabase/supabase-js'
import type { StoredDocument, StoredVersion, WorkspaceHistory } from '../shared/workspace'
import { accountClient, accountRedirect, initializeAccount, workspaceRequest } from './accountApi'
import { validateFile } from './documents'
import { Brand, PageTitle } from './ui'
import './account.css'

type AuthView = 'login' | 'signup' | 'forgot' | 'reset'
const authCopy = {
  login: { heading: 'Sign in', description: 'Open your private thesis workspace.', button: 'Sign in' },
  signup: { heading: 'Create an account', description: 'Create a workspace for your thesis and revised drafts.', button: 'Create account' },
  forgot: { heading: 'Reset your password', description: 'Request a password reset link for your email address.', button: 'Send reset link' },
  reset: { heading: 'Choose a new password', description: 'Use at least 12 characters.', button: 'Update password' },
}

function AuthForm({ client, recovering, message, onReset }: { client: SupabaseClient; recovering: boolean; message: string; onReset: () => void }) {
  const [view, setView] = useState<AuthView>(recovering ? 'reset' : 'login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [notice, setNotice] = useState(message)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const copy = authCopy[view]

  function show(next: AuthView) {
    setView(next)
    setPassword('')
    setNotice('')
    setError('')
  }

  async function submit(event: FormEvent) {
    event.preventDefault()
    if (busy) return
    setBusy(true)
    setNotice('')
    setError('')
    const address = email.trim()
    try {
      if (view === 'signup') {
        const { error } = await client.auth.signUp({ email: address, password, options: { emailRedirectTo: accountRedirect('verify') } })
        if (error) throw error
        setNotice('Check your email for a verification link. Open it in this browser.')
        setPassword('')
      } else if (view === 'forgot') {
        const { error } = await client.auth.resetPasswordForEmail(address, { redirectTo: accountRedirect('recovery') })
        if (error) throw error
        setNotice('If the email is registered, a reset link will arrive shortly. Open it in this browser.')
      } else if (view === 'reset') {
        const { error } = await client.auth.updateUser({ password })
        if (error) throw error
        onReset()
      } else {
        const { error } = await client.auth.signInWithPassword({ email: address, password })
        if (error) throw error
      }
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : 'The authentication request could not be completed.')
    } finally { setBusy(false) }
  }

  return <main className="account-entry"><Brand /><section className="panel settings-section account-form">
    <p className="eyebrow"><span /> PRIVATE STUDENT WORKSPACE</p>
    <h1>{copy.heading}</h1><p className="page-description">{copy.description}</p>
    <form onSubmit={submit} className="account-fields">
      {view !== 'reset' && <label>Email address<input type="email" value={email} autoComplete="email" required maxLength={254} onChange={(event) => setEmail(event.target.value)} /></label>}
      {view !== 'forgot' && <label>{view === 'reset' ? 'New password' : 'Password'}<input type="password" value={password} autoComplete={view === 'login' ? 'current-password' : 'new-password'} required minLength={view === 'login' ? undefined : 12} maxLength={128} onChange={(event) => setPassword(event.target.value)} /></label>}
      {error && <p className="notice notice-error" role="alert"><CircleAlert size={16} />{error}</p>}
      {notice && <p className="notice" role="status">{notice}</p>}
      <button className="button button-primary" disabled={busy} type="submit">{busy ? 'Please wait…' : copy.button} <ArrowRight size={16} /></button>
    </form>
    {view !== 'reset' && <div className="account-switches">
      {view === 'login' ? <><button type="button" className="text-link" disabled={busy} onClick={() => show('signup')}>Create an account</button><button type="button" className="text-link" disabled={busy} onClick={() => show('forgot')}>Forgot password?</button></>
        : <button type="button" className="text-link" disabled={busy} onClick={() => show('login')}>Back to sign in</button>}
    </div>}
  </section></main>
}

function formatDate(date: string) { return new Date(date).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) }

function StudentDashboard({ session, signOut, accountDeleted }: { session: Session; signOut: () => Promise<void>; accountDeleted: () => void }) {
  const [history, setHistory] = useState<WorkspaceHistory>()
  const [refresh, setRefresh] = useState(0)
  const [view, setView] = useState<'documents' | 'settings'>('documents')
  const [file, setFile] = useState<{ value: File; key: string }>()
  const [target, setTarget] = useState<StoredDocument>()
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(true)
  const [dragging, setDragging] = useState(false)
  const [error, setError] = useState('')
  const [historyError, setHistoryError] = useState('')
  const [notice, setNotice] = useState('')
  const [password, setPassword] = useState('')
  const [confirmDelete, setConfirmDelete] = useState(false)
  const input = useRef<HTMLInputElement>(null)
  const upload = useRef<HTMLElement>(null)
  const token = session.access_token

  useEffect(() => {
    const controller = new AbortController()
    setLoading(true)
    setHistoryError('')
    workspaceRequest<WorkspaceHistory>('/documents', token, { signal: controller.signal })
      .then((result) => { if (!controller.signal.aborted) setHistory(result) })
      .catch((failure: Error) => { if (!controller.signal.aborted) setHistoryError(failure.message) })
      .finally(() => { if (!controller.signal.aborted) setLoading(false) })
    return () => controller.abort()
  }, [token, refresh])

  function select(files: FileList | null) {
    if (!files?.length || busy) return
    const validation = files.length === 1 ? validateFile(files[0]) : 'Choose one PDF or DOCX at a time.'
    setError(validation)
    setNotice('')
    setFile(validation ? undefined : { value: files[0], key: crypto.randomUUID() })
  }

  async function perform(action: () => Promise<void>) {
    if (busy) return
    setBusy(true)
    setError('')
    setNotice('')
    try { await action() }
    catch (failure) { setError(failure instanceof Error ? failure.message : 'The request could not be completed.') }
    finally { setBusy(false) }
  }

  async function save(event: FormEvent) {
    event.preventDefault()
    if (!file) return
    await perform(async () => {
      try {
        await workspaceRequest(target ? `/documents/${target.id}/versions` : '/documents', token, {
          method: 'POST', body: file.value,
          headers: { 'Content-Type': 'application/octet-stream', 'X-File-Name': encodeURIComponent(file.value.name), 'Idempotency-Key': file.key },
        })
        setFile(undefined)
        setTarget(undefined)
        setNotice('Document version saved.')
      } finally { setRefresh((value) => value + 1) }
    })
  }

  async function download(document: StoredDocument, version: StoredVersion) {
    await perform(async () => {
      const { url } = await workspaceRequest<{ url: string }>(`/documents/${document.id}/versions/${version.id}/download`, token)
      const link = window.document.createElement('a')
      link.href = url
      link.rel = 'noreferrer'
      window.document.body.append(link)
      link.click()
      link.remove()
    })
  }

  async function remove(document: StoredDocument) {
    if (!window.confirm(`Delete ${document.title} and every saved version?`)) return
    await perform(async () => {
      try {
        await workspaceRequest(`/documents/${document.id}`, token, { method: 'DELETE' })
        if (target?.id === document.id) { setTarget(undefined); setFile(undefined) }
        setNotice('Document and versions deleted.')
      } finally { setRefresh((value) => value + 1) }
    })
  }

  async function eraseAccount(event: FormEvent) {
    event.preventDefault()
    await perform(async () => {
      try {
        await workspaceRequest('/account', token, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) })
        accountDeleted()
      } finally {
        setPassword('')
        setRefresh((value) => value + 1)
      }
    })
  }

  const versions = history?.documents.flatMap((document) => document.versions) ?? []
  const readyCount = versions.filter((version) => version.state === 'ready').length
  const uploadDisabled = busy || history?.deletingAccount === true
  const stats = [
    { label: 'Documents', value: history?.documents.length, icon: Files },
    { label: 'Saved versions', value: history ? readyCount : undefined, icon: History },
    { label: 'Pending uploads', value: history ? versions.length - readyCount : undefined, icon: Upload },
  ]

  return <div className="account-workspace">
    <header className="topbar account-topbar"><Brand /><nav aria-label="Student workspace" className="account-nav">
      <button type="button" className="button button-secondary" aria-pressed={view === 'documents'} onClick={() => setView('documents')}>Documents</button>
      <button type="button" className="button button-secondary" aria-pressed={view === 'settings'} onClick={() => setView('settings')}>Account</button>
      <button type="button" className="button button-secondary" disabled={busy} onClick={() => void perform(signOut)}><LogOut size={16} /> Sign out</button>
    </nav></header>
    <main className="main-content account-main">
      {error && <p className="notice notice-error" role="alert"><CircleAlert size={16} />{error}</p>}
      {notice && <p className="notice" role="status">{notice}</p>}
      {history?.deletingAccount && <p className="notice" role="status"><LockKeyhole size={16} /> Account deletion is pending. You can retry it from Account.</p>}
      {view === 'documents' ? <>
        <PageTitle label="PRIVATE WORKSPACE" title="Document history" description="Save your drafts privately and keep track of every revision." action={<button type="button" className="button button-secondary" disabled={loading || busy} onClick={() => setRefresh((value) => value + 1)}><RefreshCw size={16} /> Refresh</button>} />
        {historyError && <p className="notice notice-error" role="alert"><CircleAlert size={16} />{historyError}</p>}
        <section className="metrics account-metrics" aria-label="Document statistics" aria-busy={loading}>{stats.map(({ label, value, icon: Icon }) => <article className="metric glass" key={label}><span className="tile-icon tone-mint"><Icon size={18} /></span><h3>{label}</h3><p className="metric-value">{value ?? '—'}</p></article>)}</section>
        <div className="upload-layout account-documents">
          <section className="panel upload-form" ref={upload} aria-labelledby="account-upload">
            <div className="form-section-heading"><span className="tile-icon tone-mint"><Upload size={18} /></span><div><h2 id="account-upload">{target ? 'Upload a revised version' : 'Upload a document'}</h2><p>{target ? target.title : 'PDF or DOCX, up to 20 MB per version.'}</p></div></div>
            <form onSubmit={save}>
              <input type="file" accept=".pdf,.docx" hidden ref={input} onChange={(event) => { select(event.target.files); event.target.value = '' }} />
              <button type="button" disabled={uploadDisabled} className={`dropzone ${dragging ? 'dropzone-active' : ''}`} onClick={() => input.current?.click()} onDragOver={(event) => { event.preventDefault(); setDragging(true) }} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); if (!uploadDisabled) select(event.dataTransfer.files) }}><span className="empty-icon"><UploadCloud size={24} /></span><strong>Drop a PDF or DOCX here</strong><span>Browse files or drag and drop</span></button>
              {file && <div className="file-preview"><span className="tile-icon tone-mint"><FileText size={16} /></span><div><strong>{file.value.name}</strong><span>{Math.ceil(file.value.size / 1024).toLocaleString()} KB</span></div></div>}
              <div className="upload-actions"><button type="submit" className="button button-primary" disabled={!file || uploadDisabled}>{busy ? 'Saving…' : 'Save private file'} <ArrowRight size={16} /></button>
                {target ? <button type="button" className="text-link" disabled={busy} onClick={() => { setTarget(undefined); setFile(undefined) }}>Cancel revision</button> : <span><ShieldCheck size={15} /> Private storage</span>}
              </div>
            </form>
          </section>
          <section className="panel analysis-guide" aria-labelledby="account-activity"><h2 id="account-activity">Recent activity</h2>
            {history?.events.length ? <ul>{history.events.map((event) => <li key={event.id}><History size={16} /><div><strong>{event.kind === 'version_saved' ? 'Version saved' : 'Document deleted'}</strong><p>{formatDate(event.created_at)}</p></div></li>)}</ul>
              : <p className="muted">{loading ? 'Loading activity…' : history ? 'No workspace activity yet.' : 'Activity is unavailable.'}</p>}
          </section>
        </div>
        <section className="panel account-history" aria-labelledby="account-history"><div className="panel-heading"><div><h2 id="account-history">Your documents</h2><p>Download originals or upload a revision.</p></div></div>
          {history?.documents.length ? <ul className="stored-documents">{history.documents.map((document) => <li key={document.id}>
            <div className="stored-document-heading"><div><h3>{document.title}</h3><p>{document.deleting ? 'Deletion pending' : `Added ${formatDate(document.created_at)}`}</p></div><div className="account-nav">
              {!document.deleting && document.versions.some((version) => version.state === 'ready') && <button type="button" className="button button-secondary" disabled={uploadDisabled} onClick={() => { setTarget(document); setFile(undefined); upload.current?.scrollIntoView({ block: 'start' }) }}>Upload revision</button>}
              <button type="button" className="button button-secondary" disabled={busy} onClick={() => void remove(document)}>{document.deleting ? 'Retry deletion' : 'Delete document'}</button>
            </div></div>
            <ul className="stored-versions">{document.versions.map((version) => <li key={version.id}><div><strong>Version {version.version_number}</strong><p>{version.file_name} · {formatDate(version.created_at)}</p></div><span>{version.state === 'ready' ? 'Saved' : 'Upload pending'}</span>{version.state === 'ready' && !document.deleting && <button type="button" className="text-link" disabled={busy} onClick={() => void download(document, version)}>Download file</button>}</li>)}</ul>
          </li>)}</ul> : <p className="panel-message" role={loading ? 'status' : undefined}>{loading ? 'Loading documents…' : history ? 'Your saved documents will appear here.' : 'Document history is unavailable.'}</p>}
        </section>
      </> : <>
        <PageTitle label="ACCOUNT" title="Account settings" description="Manage access to your private workspace." />
        <section className="panel settings-section account-settings"><div className="settings-heading"><span className="tile-icon tone-mint"><LockKeyhole size={17} /></span><div><h2>Verified email</h2><p>{session.user.email}</p></div></div></section>
        <section className="panel settings-section account-settings"><div className="settings-heading"><div><h2>Delete account</h2><p>Delete your account and every document and version stored in this workspace.</p></div></div>
          {confirmDelete ? <form className="account-fields" onSubmit={eraseAccount}><label>Confirm your password<input type="password" required autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} maxLength={128} /></label><div className="account-nav"><button type="submit" className="button button-secondary" disabled={busy}>Permanently delete account</button><button type="button" className="text-link" disabled={busy} onClick={() => { setConfirmDelete(false); setPassword('') }}>Cancel</button></div></form>
            : <button type="button" className="button button-secondary" disabled={busy} onClick={() => setConfirmDelete(true)}>{history?.deletingAccount ? 'Retry account deletion' : 'Delete account'}</button>}
        </section>
      </>}
    </main>
  </div>
}

function AccountSession({ client }: { client: SupabaseClient }) {
  const [session, setSession] = useState<Session | null>(null)
  const [ready, setReady] = useState(false)
  const [recovering, setRecovering] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    let current = true
    const { data: { subscription } } = client.auth.onAuthStateChange((event, next) => {
      if (event !== 'INITIAL_SESSION') setSession(next)
      if (event === 'SIGNED_OUT') setRecovering(false)
    })
    initializeAccount(client).then((initial) => {
      if (!current) return
      setSession(initial.session)
      setRecovering(initial.recovering)
      setMessage(initial.message)
      setReady(true)
    }).catch(() => {
      if (current) { setMessage('Authentication could not be initialized. Please sign in again.'); setReady(true) }
    })
    return () => { current = false; subscription.unsubscribe() }
  }, [client])

  async function signOut() {
    const { error } = await client.auth.signOut({ scope: 'local' })
    if (error) throw error
  }

  if (!ready) return <main className="account-entry"><Brand /><p role="status">Checking your session…</p></main>
  if (!session || recovering) return <AuthForm key={recovering ? 'reset' : 'sign-in'} client={client} recovering={recovering} message={message} onReset={() => setRecovering(false)} />
  return <StudentDashboard key={session.user.id} session={session} signOut={signOut} accountDeleted={() => {
    setSession(null)
    setMessage('Your account and saved files were deleted.')
    void client.auth.signOut({ scope: 'local' })
  }} />
}

export default function Account() {
  if (!accountClient) return <main className="account-entry"><Brand /><p className="notice notice-error" role="alert">The student workspace is missing its deployment configuration.</p></main>
  return <AccountSession client={accountClient} />
}
