import { createClient } from '@supabase/supabase-js'
import type { Session, SupabaseClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL?.trim()
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY?.trim()
const api = import.meta.env.VITE_THESIS_API_URL?.trim().replace(/\/$/, '')

export const accountClient = url && key && api
  ? createClient(url, key, { auth: { flowType: 'pkce', detectSessionInUrl: false, storageKey: 'thesis-checker-auth' } })
  : null

type InitialAuth = { session: Session | null; recovering: boolean; message: string }
let initialAuth: Promise<InitialAuth> | undefined

export function initializeAccount(client: SupabaseClient) {
  initialAuth ??= (async () => {
    const callback = new URL(window.location.href)
    const code = callback.searchParams.get('code')
    const flow = callback.searchParams.get('auth')
    const callbackFailed = callback.searchParams.has('error') || callback.searchParams.has('error_code')
    if (code || flow || callbackFailed) {
      for (const field of ['code', 'auth', 'error', 'error_code', 'error_description']) callback.searchParams.delete(field)
      window.history.replaceState(window.history.state, '', callback)
    }
    if (code) {
      const { data, error } = await client.auth.exchangeCodeForSession(code)
      if (error || !data.session) return { session: null, recovering: false, message: 'This link could not be used. Request a new link and open it in the browser where you requested it.' }
      return { session: data.session, recovering: flow === 'recovery', message: '' }
    }
    if (callbackFailed || flow) return { session: null, recovering: false, message: 'This email link is missing or expired. Request a new link and try again.' }
    const { data, error } = await client.auth.getSession()
    return { session: data.session, recovering: false, message: error ? 'Your session could not be restored. Please sign in again.' : '' }
  })()
  return initialAuth
}

export function accountRedirect(flow: 'verify' | 'recovery') {
  const redirect = new URL(window.location.pathname, window.location.origin)
  redirect.searchParams.set('auth', flow)
  return redirect.href
}

export async function workspaceRequest<T>(path: string, token: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers)
  headers.set('Authorization', `Bearer ${token}`)
  const response = await fetch(`${api}/api/v1${path}`, { ...options, headers, credentials: 'omit', cache: 'no-store' })
  if (response.status === 204) return undefined as T
  const body = await response.json().catch(() => null)
  if (!response.ok) throw new Error(typeof body?.error === 'string' ? body.error : 'The workspace API could not complete the request.')
  if (body === null) throw new Error('The workspace API returned an unexpected response.')
  return body as T
}
