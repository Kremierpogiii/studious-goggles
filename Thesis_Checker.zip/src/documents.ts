import { createStore, get, update } from 'idb-keyval'
import { MAX_UPLOAD_BYTES } from '../shared/workspace'
import type { Report, Source } from './analysis'
import type { AnalysisResponse } from './analysis.worker'

export const maxFileSize = MAX_UPLOAD_BYTES
export const maxSources = 5
const maxTextLength = 600_000
const maxXmlBytes = 20 * 1024 * 1024
const reportStore = createStore('thesis-checker', 'reports')

interface ZipByteStream {
  on(event: 'data', listener: (chunk: Uint8Array) => void): ZipByteStream
  on(event: 'error', listener: (error: Error) => void): ZipByteStream
  on(event: 'end', listener: () => void): ZipByteStream
  pause(): void
  resume(): void
}

export const readReports = async () => (await get<Report[]>('history', reportStore)) ?? []

export function upsertReport(reports: Report[], report: Report) {
  const index = reports.findIndex(({ id }) => id === report.id)
  if (index === -1) return [report, ...reports]
  const updated = [...reports]
  updated[index] = report
  return updated
}

export const saveReport = (report: Report) => update<Report[]>('history', (reports) => upsertReport(reports ?? [], report), reportStore)

export function validateFile(file: File) {
  if (!/\.(pdf|docx)$/i.test(file.name)) return `${file.name} is unsupported. Choose a PDF or DOCX file.`
  if (!file.size) return `${file.name} is empty.`
  if (file.size > maxFileSize) return `${file.name} exceeds the 20 MB file limit.`
  return ''
}

function readFile(file: File, onProgress: (progress: number) => void) {
  return new Promise<ArrayBuffer>((resolve, reject) => {
    const reader = new FileReader()
    reader.onprogress = (event) => {
      if (event.lengthComputable) onProgress(event.loaded / event.total * 0.2)
    }
    reader.onload = () => { onProgress(0.2); resolve(reader.result as ArrayBuffer) }
    reader.onerror = () => reject(new Error(`Could not read ${file.name}.`))
    reader.readAsArrayBuffer(file)
  })
}

async function extractPdf(bytes: ArrayBuffer, onProgress: (progress: number) => void) {
  const [pdf, worker] = await Promise.all([
    import('pdfjs-dist'),
    import('pdfjs-dist/build/pdf.worker.min.mjs?url'),
  ])
  pdf.GlobalWorkerOptions.workerSrc = worker.default
  const task = pdf.getDocument({ data: bytes, isEvalSupported: false, useSystemFonts: true })

  try {
    const document = await task.promise
    if (document.numPages > 500) throw new Error('This PDF exceeds the 500-page limit.')
    const pages: string[] = []
    let characterCount = 0
    for (let index = 1; index <= document.numPages; index++) {
      const page = await document.getPage(index)
      const content = await page.getTextContent()
      let text = ''
      let lastBaseline: number | undefined
      for (const item of content.items) {
        if (!('str' in item)) continue
        const baseline = item.transform[5]
        if (text && !text.endsWith('\n') && lastBaseline !== undefined && Math.abs(baseline - lastBaseline) > 2) text += '\n'
        text += item.str
        if (item.hasEOL) text += '\n'
        lastBaseline = baseline
      }
      pages.push(text.trim())
      characterCount += text.length
      if (characterCount > maxTextLength) throw new Error('This document exceeds the 600,000-character limit.')
      onProgress(0.2 + index / document.numPages * 0.8)
      page.cleanup()
    }
    return pages.join('\n\n')
  } finally {
    await task.destroy()
  }
}

async function extractDocx(bytes: ArrayBuffer, onProgress: (progress: number) => void) {
  const { default: JSZip } = await import('jszip')
  const zip = await JSZip.loadAsync(bytes)
  const entry = zip.file('word/document.xml')
  if (!entry) throw new Error('The selected file does not contain a DOCX document body.')
  const xml = await new Promise<string>((resolve, reject) => {
    const decoder = new TextDecoder()
    // JSZip ships this stream method but omits it from the JSZipObject type.
    const stream = (entry as typeof entry & { internalStream(type: 'uint8array'): ZipByteStream }).internalStream('uint8array')
    const parts: string[] = []
    let length = 0
    stream.on('data', (chunk) => {
      length += chunk.length
      if (length > maxXmlBytes) {
        stream.pause()
        reject(new Error('The expanded DOCX body exceeds the 20 MB limit.'))
        return
      }
      parts.push(decoder.decode(chunk, { stream: true }))
    }).on('error', reject).on('end', () => resolve(parts.join('') + decoder.decode())).resume()
  })
  onProgress(0.75)
  const document = new DOMParser().parseFromString(xml, 'application/xml')
  if (document.querySelector('parsererror')) throw new Error('This DOCX contains unreadable document XML.')
  const namespace = document.documentElement.namespaceURI
  const body = document.getElementsByTagNameNS(namespace, 'body')[0]
  if (!body) throw new Error('This DOCX does not contain a readable document body.')
  function runText(element: Element): string {
    if (element.namespaceURI === namespace) {
      if (element.localName === 'p') return ''
      if (element.localName === 't') return element.textContent ?? ''
      if (element.localName === 'tab') return '\t'
      if (element.localName === 'br' || element.localName === 'cr') return '\n'
    }
    return Array.from(element.children, runText).join('')
  }
  const paragraphs = Array.from(body.getElementsByTagNameNS(namespace, 'p'), (paragraph) => Array.from(paragraph.children, runText).join(''))
  onProgress(1)
  return paragraphs.join('\n')
}

export async function extractDocument(file: File, onProgress: (progress: number) => void) {
  const validation = validateFile(file)
  if (validation) throw new Error(validation)
  const bytes = await readFile(file, onProgress)
  const text = (await (/\.pdf$/i.test(file.name) ? extractPdf(bytes, onProgress) : extractDocx(bytes, onProgress))).trim()
  if (!text) throw new Error('No readable text was found. Try a text-based PDF or a DOCX with selectable text.')
  if (text.length > maxTextLength) throw new Error('This document exceeds the 600,000-character limit.')
  return text
}

export function analyzeInWorker(draft: Source, sources: Source[]) {
  return new Promise<Report>((resolve, reject) => {
    const worker = new Worker(new URL('./analysis.worker.ts', import.meta.url), { type: 'module' })
    worker.onmessage = (event: MessageEvent<AnalysisResponse>) => {
      worker.terminate()
      if ('report' in event.data) resolve(event.data.report)
      else reject(new Error(event.data.error))
    }
    worker.onerror = () => {
      worker.terminate()
      reject(new Error('The analysis worker could not run. Try reloading the workspace.'))
    }
    worker.postMessage({ draft, sources })
  })
}

export function downloadReport(report: Report) {
  const details = report.findings.map((finding, index) => [
    `${index + 1}. ${finding.title} (${finding.severity})`, finding.detail,
    `Passage: ${report.text.slice(finding.start, finding.end)}`,
    ...(finding.source ? [`Source: ${finding.source.name}`, `Source excerpt: ${finding.source.excerpt}`] : []),
  ].join('\n'))
  const content = [
    'Thesis Checker · Analysis report', report.name, new Date(report.createdAt).toLocaleString(),
    `${report.wordCount.toLocaleString()} words · ${report.citationsChecked} author–date citations checked`,
    `Source overlap: ${report.similarity === null ? 'Unavailable' : `${report.similarity}% against supplied sources`}`,
    `Comparison files: ${report.sources.join(', ') || 'None'}`,
    'Review suggestions in context. Source overlap measures exact wording against supplied files.',
    ...details,
  ].join('\n\n')
  const url = URL.createObjectURL(new Blob([content], { type: 'text/plain;charset=utf-8' }))
  const link = document.createElement('a')
  link.href = url
  link.download = `${report.name.replace(/\.(pdf|docx)$/i, '')}-analysis.txt`
  link.hidden = true
  document.body.append(link)
  link.click()
  link.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 30_000)
}
