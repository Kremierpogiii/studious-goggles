import { Activity, ArrowDownUp, ArrowRight, FileCheck2, Files, Fingerprint, ListFilter, LockKeyhole, Quote, ScanText, Settings2, ShieldCheck, Sparkles, Upload, Workflow } from 'lucide-react'
import { useState } from 'react'
import type { FormEvent } from 'react'
import type { Report } from './analysis'
import { Brand, EmptyReports, Hero, links, PageTitle, ReportTable, reportLink } from './ui'

const metricCards = [
  { key: 'documents', label: 'Documents analyzed', icon: Files, tone: 'mint', caption: 'Reports on this device' },
  { key: 'citation', label: 'Citation issues', icon: Quote, tone: 'sky', caption: 'References to review' },
  { key: 'redundancy', label: 'Redundancy findings', icon: Workflow, tone: 'amber', caption: 'Wording suggestions' },
  { key: 'similarity', label: 'Latest source overlap', icon: Fingerprint, tone: 'emerald', caption: 'Against supplied sources' },
] as const

export function Dashboard({ reports, loading }: { reports: Report[]; loading: boolean }) {
  const lastComparison = reports.find((report) => report.similarity !== null)
  const count = { citation: 0, redundancy: 0 }
  for (const report of reports) for (const finding of report.findings) {
    if (finding.category === 'citation' || finding.category === 'redundancy') count[finding.category]++
  }
  const metrics = { documents: reports.length, ...count, similarity: lastComparison ? `${lastComparison.similarity}%` : '—' }

  return <>
    <PageTitle label="YOUR RESEARCH WORKSPACE" title="Workspace overview" description="A clearer path from first draft to final submission." action={<a href={links.upload} className="button button-primary"><Upload size={16} /> New analysis</a>} />
    <Hero />
    <div className="section-heading overview-heading"><div><h2>Analysis overview</h2><p>Findings across your research documents.</p></div><span className="quiet-chip"><Activity size={13} /> This device</span></div>
    <section className="metrics" aria-label="Analysis metrics" aria-busy={loading}>
      {metricCards.map(({ key, label, icon: Icon, tone, caption }) => <article className="metric glass" key={key}>
        <span className={`tile-icon tone-${tone}`}><Icon size={18} strokeWidth={1.8} /></span>
        <h3>{label}</h3><p className="metric-value">{loading ? '—' : typeof metrics[key] === 'number' ? metrics[key].toLocaleString() : metrics[key]}</p>
        <p className="metric-caption">{key === 'similarity' && !lastComparison ? 'No sources compared yet' : caption}</p>
      </article>)}
    </section>
    <div className="dashboard-bottom">
      <section className="panel" aria-labelledby="recent-reports">
        <div className="panel-heading"><div><h2 id="recent-reports">Recent reports</h2><p>Pick up where you left off.</p></div><a className="text-link" href={links.reports}>View all <ArrowRight size={15} /></a></div>
        {loading ? <p className="panel-message" role="status">Loading local reports…</p> : reports.length ? <ReportTable reports={reports.slice(0, 4)} /> : <EmptyReports compact />}
      </section>
      <section className="panel activity-panel" aria-labelledby="recent-activity">
        <div className="panel-heading"><div><h2 id="recent-activity">Recent activity</h2><p>Your latest workspace updates.</p></div><Activity size={17} className="muted" /></div>
        {reports.length ? <ul className="activity-list">{reports.slice(0, 3).map((report) => <li key={report.id}>
          <span className="tile-icon tone-mint"><FileCheck2 size={16} /></span><div><a href={reportLink(report.id)}>Analysis completed</a><p>{report.name}</p><time dateTime={report.createdAt}>{new Date(report.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</time></div>
        </li>)}</ul> : <div className="activity-empty"><span className="tile-icon tone-mint"><Activity size={17} /></span><div><h3>{loading ? 'Loading activity…' : 'No activity yet'}</h3><p>Your analyses will appear here as you work.</p></div></div>}
      </section>
    </div>
  </>
}

export function Reports({ reports, loading }: { reports: Report[]; loading: boolean }) {
  const [query, setQuery] = useState('')
  const [newest, setNewest] = useState(true)
  const filtered = reports.filter((report) => report.name.toLowerCase().includes(query.trim().toLowerCase()))
  if (!newest) filtered.reverse()
  return <>
    <PageTitle label="REPORT LIBRARY" title="Analysis reports" description="Revisit findings and export your document reviews." action={<a href={links.upload} className="button button-primary"><Upload size={16} /> New analysis</a>} />
    <section className="panel report-list" aria-label="Report history">
      <div className="panel-heading report-toolbar">
        <label className="input-with-icon"><ListFilter size={17} /><span className="sr-only">Filter by document name</span><input placeholder="Filter by document name" value={query} onChange={(event) => setQuery(event.target.value)} /></label>
        <button className="button button-secondary" type="button" onClick={() => setNewest(!newest)}><ArrowDownUp size={16} /> {newest ? 'Newest first' : 'Oldest first'}</button>
      </div>
      {loading ? <p className="panel-message" role="status">Loading local reports…</p> : !reports.length ? <EmptyReports /> : !filtered.length ? <p className="panel-message">No reports match your search.</p> : <ReportTable reports={filtered} />}
    </section>
  </>
}

export interface Preferences { compact: boolean; reduceMotion: boolean }
const defaultPreferences: Preferences = { compact: false, reduceMotion: false }

export function readPreferences(): Preferences {
  try {
    const settings = JSON.parse(localStorage.getItem('thesis-checker-preferences') ?? '{}') as Partial<Preferences>
    return {
      compact: settings.compact === true,
      reduceMotion: settings.reduceMotion === true,
    }
  } catch { return defaultPreferences }
}

export function Settings({ preferences, onSave }: { preferences: Preferences; onSave: (settings: Preferences) => void }) {
  const [values, setValues] = useState(preferences)
  const [message, setMessage] = useState('')
  function save(event: FormEvent) {
    event.preventDefault()
    try {
      localStorage.setItem('thesis-checker-preferences', JSON.stringify(values))
      onSave(values)
      setMessage('Preferences saved on this device.')
    } catch { setMessage('Browser storage is unavailable. Your changes could not be saved.') }
  }
  return <>
    <PageTitle label="PREFERENCES" title="Workspace settings" description="Personalize the workspace on this browser and device." />
    <form className="settings-form" onSubmit={save} onChange={() => setMessage('')}>
      <section className="panel settings-section"><div className="settings-heading"><span className="tile-icon tone-sky"><Settings2 size={19} /></span><div><h2>Appearance</h2><p>Adjust density and motion in Emerald Intelligence.</p></div></div>
        <label className="switch-row"><span><strong>Compact tables</strong><small>Reduce spacing between rows in report lists.</small></span><input type="checkbox" checked={values.compact} onChange={(event) => setValues({ ...values, compact: event.target.checked })} /></label>
        <label className="switch-row"><span><strong>Reduce motion</strong><small>Limit decorative animation and transitions.</small></span><input type="checkbox" checked={values.reduceMotion} onChange={(event) => setValues({ ...values, reduceMotion: event.target.checked })} /></label>
      </section>
      <section className="panel settings-section"><div className="settings-heading"><span className="tile-icon tone-emerald"><LockKeyhole size={19} /></span><div><h2>Browser storage</h2><p>Reports and appearance preferences are saved in this browser.</p></div></div></section>
      <div className="settings-actions"><button type="submit" className="button button-primary">Save preferences</button><p role="status">{message}</p></div>
    </form>
  </>
}

export function Landing() {
  return <div className="landing">
    <header className="landing-nav"><Brand /><nav aria-label="Product navigation"><a href="#/about/features">Features</a><a href="#/about/how-it-works">How it works</a><a className="button button-secondary" href={links.dashboard}>Open workspace <ArrowRight size={16} /></a></nav></header>
    <main id="main-content" tabIndex={-1}>
      <Hero landing />
      <section className="landing-section" id="features"><p className="eyebrow"><span /> BUILT FOR ACADEMIC DRAFTS</p><h2>Give each revision a clear focus.</h2>
        <div className="landing-grid">
          <article className="glass"><span className="tile-icon tone-mint"><Quote size={20} /></span><h3>Citation consistency</h3><p>Review author–date citations that may need a corresponding reference entry.</p></article>
          <article className="glass"><span className="tile-icon tone-amber"><Sparkles size={20} /></span><h3>Clearer writing</h3><p>Find repeated words, wordy phrases, and a few common punctuation and spacing issues.</p></article>
          <article className="glass"><span className="tile-icon tone-sky"><ScanText size={20} /></span><h3>Source comparison</h3><p>See exact wording shared with files you provide and inspect passages in context.</p></article>
        </div>
      </section>
      <section className="landing-section" id="how-it-works"><p className="eyebrow"><span /> HOW IT WORKS</p><h2>From draft to review in three steps.</h2>
        <ol className="landing-steps"><li><span>01</span><div><h3>Add your draft</h3><p>Choose a text-based PDF or DOCX.</p></div></li><li><span>02</span><div><h3>Run your checks</h3><p>Add comparison files if you want to check overlap.</p></div></li><li><span>03</span><div><h3>Review and export</h3><p>Open flagged passages and save the report for revisions.</p></div></li></ol>
        <a className="button button-primary" href={links.upload}>Analyze a document <ArrowRight size={17} /></a>
      </section>
    </main>
    <footer className="landing-footer"><Brand /><p><ShieldCheck size={16} /> Analysis stays in your browser.</p><a href={links.settings}>Workspace settings</a></footer>
  </div>
}
