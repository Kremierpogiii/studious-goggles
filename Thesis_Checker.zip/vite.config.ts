import tailwindcss from '@tailwindcss/vite'
import { Buffer } from 'node:buffer'
import { cwd } from 'node:process'
import { defineConfig, loadEnv } from 'vite'

function isPublishableKey(value: string) {
  if (value.startsWith('sb_publishable_')) return true
  try { return JSON.parse(Buffer.from(value.split('.')[1], 'base64url').toString('utf8')).role === 'anon' }
  catch { return false }
}

export default defineConfig(({ command, mode }) => {
  const env = loadEnv(mode, cwd(), 'VITE_')
  const account = mode === 'account'
  const allowedOrigins: string[] = []
  if (account) {
    if (!env.VITE_SUPABASE_PUBLISHABLE_KEY) throw new Error('The account workspace requires VITE_SUPABASE_PUBLISHABLE_KEY.')
    if (!isPublishableKey(env.VITE_SUPABASE_PUBLISHABLE_KEY)) throw new Error('VITE_SUPABASE_PUBLISHABLE_KEY must be a public Supabase key.')
    for (const key of ['VITE_SUPABASE_URL', 'VITE_THESIS_API_URL']) {
      const value = env[key]
      if (!value) throw new Error(`The account workspace requires ${key}.`)
      const url = new URL(value)
      const loopback = ['localhost', '127.0.0.1'].includes(url.hostname) && url.protocol === 'http:'
      if ((url.protocol !== 'https:' && !(command === 'serve' && loopback)) || url.username || url.password || url.pathname !== '/' || url.search || url.hash) {
        throw new Error(`${key} must be a bare HTTPS origin for deployment.`)
      }
      allowedOrigins.push(url.origin)
    }
  }
  return {
    base: './',
    define: { 'import.meta.env.VITE_WORKSPACE_MODE': JSON.stringify(account ? 'account' : 'local') },
    plugins: [tailwindcss(), {
      name: 'student-workspace-network-policy',
      apply: 'build',
      transformIndexHtml() {
        if (!account) return []
        return [{ tag: 'meta', attrs: { 'http-equiv': 'Content-Security-Policy', content: `connect-src 'self' ${allowedOrigins.join(' ')}` }, injectTo: 'head-prepend' }]
      },
    }],
  }
})
