begin;
create extension if not exists pgtap with schema extensions;
set local search_path = public, extensions;

select plan(13);
select is((select public from storage.buckets where id = 'thesis-checker-private'), false, 'the thesis bucket is private');
select is((select file_size_limit from storage.buckets where id = 'thesis-checker-private'), 20971520::bigint, 'the bucket limits uploads to 20 MB');
select ok(not has_table_privilege('anon', 'public.thesis_versions', 'SELECT'), 'anonymous clients cannot read version records');
select ok(not has_table_privilege('authenticated', 'public.thesis_versions', 'INSERT'), 'clients cannot write version records directly');
select ok(not has_function_privilege('authenticated', 'public.thesis_reserve_upload(uuid,uuid,text,text,integer,text,uuid)', 'EXECUTE'), 'the upload RPC is server-only');

insert into auth.users (id, email, aud, role) values
  ('f1000000-0000-0000-0000-000000000001', 'owner.fixture@example.invalid', 'authenticated', 'authenticated'),
  ('f1000000-0000-0000-0000-000000000002', 'other.fixture@example.invalid', 'authenticated', 'authenticated');

set local role service_role;
do $$
declare v_first jsonb; v_second jsonb;
begin
  v_first := public.thesis_reserve_upload('f1000000-0000-0000-0000-000000000001', null, 'Draft.pdf', 'application/pdf', 100, repeat('a', 64), 'f2000000-0000-0000-0000-000000000001');
  perform set_config('test.thesis_document', v_first->>'document_id', true);
  perform set_config('test.thesis_version', v_first->>'id', true);
  perform public.thesis_finish_upload('f1000000-0000-0000-0000-000000000001', (v_first->>'id')::uuid);
  v_second := public.thesis_reserve_upload('f1000000-0000-0000-0000-000000000001', (v_first->>'document_id')::uuid, 'Revision.pdf', 'application/pdf', 110, repeat('b', 64), 'f2000000-0000-0000-0000-000000000002');
  perform set_config('test.thesis_revision', v_second->>'id', true);
end;
$$;
select is((select state from public.thesis_versions where id = current_setting('test.thesis_version')::uuid), 'ready', 'a completed upload is visible as ready');
select is((select version_number from public.thesis_versions where id = current_setting('test.thesis_revision')::uuid), 2, 'a revised file receives a separate version');
select is(public.thesis_reserve_upload('f1000000-0000-0000-0000-000000000001', null, 'Draft.pdf', 'application/pdf', 100, repeat('a', 64), 'f2000000-0000-0000-0000-000000000001')->>'id', current_setting('test.thesis_version'), 'retry resolves to the same version');
select is(public.thesis_reserve_upload('f1000000-0000-0000-0000-000000000002', current_setting('test.thesis_document')::uuid, 'Foreign.pdf', 'application/pdf', 100, repeat('c', 64), 'f2000000-0000-0000-0000-000000000003')->>'error', 'document_unavailable', 'a different student cannot reserve a revision');
select is(public.thesis_begin_delete('f1000000-0000-0000-0000-000000000001', current_setting('test.thesis_document')::uuid)->>'error', 'uploads_pending', 'deletion waits for an active upload');

set local role authenticated;
set local "request.jwt.claim.sub" = 'f1000000-0000-0000-0000-000000000002';
select is((select count(*) from public.thesis_versions), 0::bigint, 'RLS hides every version from another student');
select is((select count(*) from public.thesis_documents), 0::bigint, 'RLS hides another student document');
set local "request.jwt.claim.sub" = 'f1000000-0000-0000-0000-000000000001';
select is((select count(*) from public.thesis_versions), 2::bigint, 'RLS permits the owner to read both versions');

reset role;
select * from finish();
rollback;
