begin;

create table public.thesis_accounts (
  id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  deletion_requested_at timestamptz
);

create table public.thesis_documents (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.thesis_accounts(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 200),
  created_at timestamptz not null default now(),
  deleting boolean not null default false,
  unique (id, owner_id)
);

create table public.thesis_versions (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null,
  document_id uuid not null,
  version_number integer not null check (version_number > 0),
  file_name text not null check (char_length(file_name) between 1 and 200),
  mime_type text not null check (mime_type in ('application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')),
  size_bytes integer not null check (size_bytes between 1 and 20971520),
  sha256 text not null check (sha256 ~ '^[a-f0-9]{64}$'),
  request_key uuid not null,
  object_key text not null unique,
  state text not null default 'uploading' check (state in ('uploading', 'ready')),
  created_at timestamptz not null default now(),
  foreign key (document_id, owner_id) references public.thesis_documents(id, owner_id) on delete cascade,
  unique (document_id, version_number),
  unique (owner_id, request_key),
  check (object_key = owner_id::text || '/' || document_id::text || '/' || id::text)
);

create table public.thesis_events (
  id bigint generated always as identity primary key,
  owner_id uuid not null references public.thesis_accounts(id) on delete cascade,
  document_id uuid,
  kind text not null check (kind in ('version_saved', 'document_deleted')),
  created_at timestamptz not null default now()
);

create index thesis_documents_owner_idx on public.thesis_documents (owner_id, created_at desc);
create index thesis_versions_owner_document_idx on public.thesis_versions (owner_id, document_id, version_number desc);
create index thesis_upload_cleanup_idx on public.thesis_versions (created_at) where state = 'uploading';
create index thesis_events_owner_idx on public.thesis_events (owner_id, created_at desc);

alter table public.thesis_accounts enable row level security;
alter table public.thesis_documents enable row level security;
alter table public.thesis_versions enable row level security;
alter table public.thesis_events enable row level security;

revoke all on public.thesis_accounts, public.thesis_documents, public.thesis_versions, public.thesis_events from public, anon, authenticated;
grant select on public.thesis_accounts, public.thesis_documents, public.thesis_versions, public.thesis_events to authenticated;
grant all on public.thesis_accounts, public.thesis_documents, public.thesis_versions, public.thesis_events to service_role;
grant usage on sequence public.thesis_events_id_seq to service_role;

create policy thesis_account_owner on public.thesis_accounts for select to authenticated using ((select auth.uid()) = id);
create policy thesis_document_owner on public.thesis_documents for select to authenticated using ((select auth.uid()) = owner_id);
create policy thesis_version_owner on public.thesis_versions for select to authenticated using ((select auth.uid()) = owner_id);
create policy thesis_event_owner on public.thesis_events for select to authenticated using ((select auth.uid()) = owner_id);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('thesis-checker-private', 'thesis-checker-private', false, 20971520,
        array['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']);

-- Only the API uses this bucket. This guard also applies if the project has
-- permissive policies for other buckets.
create policy thesis_storage_api_only on storage.objects as restrictive for all to anon, authenticated
using (bucket_id <> 'thesis-checker-private') with check (bucket_id <> 'thesis-checker-private');

create function public.thesis_reserve_upload(
  p_owner uuid, p_document uuid, p_name text, p_mime text, p_size integer, p_sha text, p_request uuid
) returns jsonb language plpgsql security invoker set search_path = '' as $$
declare
  v_existing public.thesis_versions%rowtype;
  v_document uuid;
  v_id uuid := gen_random_uuid();
  v_number integer;
  v_key text;
begin
  perform pg_advisory_xact_lock(hashtextextended(p_owner::text, 0));
  insert into public.thesis_accounts (id) values (p_owner) on conflict (id) do nothing;
  if exists (select 1 from public.thesis_accounts where id = p_owner and deletion_requested_at is not null) then
    return jsonb_build_object('error', 'account_deleting');
  end if;

  select * into v_existing from public.thesis_versions where owner_id = p_owner and request_key = p_request;
  if found then
    if v_existing.sha256 <> p_sha or v_existing.file_name <> p_name or
       (p_document is not null and v_existing.document_id <> p_document) or
       (p_document is null and v_existing.version_number <> 1) then
      return jsonb_build_object('error', 'idempotency_conflict');
    end if;
    if exists (select 1 from public.thesis_documents where id = v_existing.document_id and deleting) then
      return jsonb_build_object('error', 'document_unavailable');
    end if;
    return jsonb_build_object('id', v_existing.id, 'document_id', v_existing.document_id, 'state', v_existing.state, 'existing', true);
  end if;

  if (select count(*) from public.thesis_versions where owner_id = p_owner and state = 'uploading') >= 2 then
    return jsonb_build_object('error', 'too_many_uploads');
  end if;
  if (select count(*) >= 100 or coalesce(sum(size_bytes), 0) + p_size > 262144000 from public.thesis_versions where owner_id = p_owner) then
    return jsonb_build_object('error', 'storage_quota');
  end if;

  if p_document is null then
    insert into public.thesis_documents (owner_id, title) values (p_owner, p_name) returning id into v_document;
  else
    select id into v_document from public.thesis_documents where id = p_document and owner_id = p_owner and not deleting;
    if not found then return jsonb_build_object('error', 'document_unavailable'); end if;
    if not exists (select 1 from public.thesis_versions where document_id = v_document and state = 'ready') then
      return jsonb_build_object('error', 'document_unavailable');
    end if;
  end if;

  select coalesce(max(version_number), 0) + 1 into v_number from public.thesis_versions where document_id = v_document;
  v_key := p_owner::text || '/' || v_document::text || '/' || v_id::text;
  insert into public.thesis_versions (id, owner_id, document_id, version_number, file_name, mime_type, size_bytes, sha256, request_key, object_key)
  values (v_id, p_owner, v_document, v_number, p_name, p_mime, p_size, p_sha, p_request, v_key);
  return jsonb_build_object('id', v_id, 'document_id', v_document, 'object_key', v_key, 'state', 'uploading', 'existing', false);
end;
$$;

create function public.thesis_finish_upload(p_owner uuid, p_version uuid)
returns boolean language plpgsql security invoker set search_path = '' as $$
declare v_document uuid;
begin
  perform pg_advisory_xact_lock(hashtextextended(p_owner::text, 0));
  update public.thesis_versions set state = 'ready' where id = p_version and owner_id = p_owner and state = 'uploading'
    and created_at >= now() - interval '30 minutes'
    and exists (select 1 from public.thesis_documents where id = document_id and not deleting)
    and exists (select 1 from public.thesis_accounts where id = p_owner and deletion_requested_at is null)
    returning document_id into v_document;
  if not found then return false; end if;
  insert into public.thesis_events (owner_id, document_id, kind) values (p_owner, v_document, 'version_saved');
  return true;
end;
$$;

create function public.thesis_purge_stale_upload(p_owner uuid, p_version uuid)
returns void language plpgsql security invoker set search_path = '' as $$
declare v_document uuid;
begin
  perform pg_advisory_xact_lock(hashtextextended(p_owner::text, 0));
  delete from public.thesis_versions where id = p_version and owner_id = p_owner and state = 'uploading'
    and created_at < now() - interval '30 minutes' returning document_id into v_document;
  if v_document is not null then
    delete from public.thesis_documents where id = v_document and owner_id = p_owner and not deleting
      and not exists (select 1 from public.thesis_versions where document_id = v_document);
  end if;
end;
$$;

create function public.thesis_expired_uploads()
returns table (id uuid, owner_id uuid, object_key text)
language sql stable security invoker set search_path = '' as $$
  select v.id, v.owner_id, v.object_key from public.thesis_versions v
  where v.state = 'uploading' and v.created_at < now() - interval '30 minutes'
  order by v.created_at limit 50
$$;

create function public.thesis_begin_delete(p_owner uuid, p_document uuid)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare v_keys jsonb;
begin
  perform pg_advisory_xact_lock(hashtextextended(p_owner::text, 0));
  if p_document is not null and not exists (select 1 from public.thesis_documents where id = p_document and owner_id = p_owner) then
    return jsonb_build_object('error', 'document_unavailable');
  end if;
  if exists (select 1 from public.thesis_versions where owner_id = p_owner and (p_document is null or document_id = p_document)
    and state = 'uploading' and created_at >= now() - interval '30 minutes') then
    return jsonb_build_object('error', 'uploads_pending');
  end if;
  if p_document is null then
    insert into public.thesis_accounts (id, deletion_requested_at) values (p_owner, now())
      on conflict (id) do update set deletion_requested_at = coalesce(thesis_accounts.deletion_requested_at, now());
  end if;
  update public.thesis_documents set deleting = true where owner_id = p_owner and (p_document is null or id = p_document);
  select coalesce(jsonb_agg(object_key), '[]'::jsonb) into v_keys from public.thesis_versions where owner_id = p_owner and (p_document is null or document_id = p_document);
  return jsonb_build_object('keys', v_keys);
end;
$$;

create function public.thesis_finish_document_delete(p_owner uuid, p_document uuid)
returns void language plpgsql security invoker set search_path = '' as $$
begin
  perform pg_advisory_xact_lock(hashtextextended(p_owner::text, 0));
  delete from public.thesis_documents where id = p_document and owner_id = p_owner and deleting;
  if found then insert into public.thesis_events (owner_id, document_id, kind) values (p_owner, p_document, 'document_deleted'); end if;
end;
$$;

revoke execute on function public.thesis_reserve_upload(uuid, uuid, text, text, integer, text, uuid),
  public.thesis_finish_upload(uuid, uuid), public.thesis_purge_stale_upload(uuid, uuid), public.thesis_expired_uploads(),
  public.thesis_begin_delete(uuid, uuid), public.thesis_finish_document_delete(uuid, uuid) from public, anon, authenticated;
grant execute on function public.thesis_reserve_upload(uuid, uuid, text, text, integer, text, uuid),
  public.thesis_finish_upload(uuid, uuid), public.thesis_purge_stale_upload(uuid, uuid), public.thesis_expired_uploads(),
  public.thesis_begin_delete(uuid, uuid), public.thesis_finish_document_delete(uuid, uuid) to service_role;

commit;
