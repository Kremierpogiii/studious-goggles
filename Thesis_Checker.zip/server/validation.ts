import { createHash } from 'node:crypto'
import JSZip from 'jszip'
import sax from 'sax'
import { DOCX_MIME, MAX_UPLOAD_BYTES, PDF_MIME } from '../shared/workspace.ts'
import type { DocumentMime } from '../shared/workspace.ts'
import { HttpError } from './errors.ts'

export function readFileName(value: string | undefined) {
  let name: string
  try { name = decodeURIComponent(value ?? '').normalize('NFC').trim() }
  catch { throw new HttpError(400, 'The filename could not be decoded.') }
  if (!name || Array.from(name).length > 200 || /[\p{Cc}\p{Cf}/\\]/u.test(name)) throw new HttpError(400, 'Choose a valid filename up to 200 characters.')
  if (!/\.(pdf|docx)$/i.test(name)) throw new HttpError(415, 'Choose a PDF or DOCX file.')
  return name
}

async function validatePdf(bytes: Buffer) {
  if (!/^%PDF-\d\.\d/.test(bytes.subarray(0, 12).toString('ascii')) || !/%%EOF\s*$/.test(bytes.subarray(-1024).toString('latin1'))) {
    throw new HttpError(422, 'This file does not have a valid PDF header and trailer.')
  }
  const pdf = await import('pdfjs-dist/legacy/build/pdf.mjs')
  const task = pdf.getDocument({ data: Uint8Array.from(bytes), stopAtErrors: true, isEvalSupported: false, useSystemFonts: false, verbosity: 0 })
  try {
    const document = await task.promise
    if (document.numPages < 1 || document.numPages > 500) throw new HttpError(422, 'PDFs must contain between 1 and 500 pages.')
    await document.getPage(document.numPages)
  } catch (error) {
    if (error instanceof HttpError) throw error
    throw new HttpError(422, 'The PDF could not be opened. Choose an unencrypted PDF that opens in a document reader.')
  } finally { await task.destroy() }
}

type ZipEntry = JSZip.JSZipObject
interface ZipStream {
  on(event: 'data', listener: (chunk: Uint8Array) => void): ZipStream
  on(event: 'error', listener: (error: Error) => void): ZipStream
  on(event: 'end', listener: () => void): ZipStream
  pause(): void
  resume(): void
}

function readXml(entry: ZipEntry, byteLimit: number) {
  return new Promise<string>((resolve, reject) => {
    // JSZip exposes the bounded streaming API but omits it from its types.
    const stream = (entry as ZipEntry & { internalStream(type: 'uint8array'): ZipStream }).internalStream('uint8array')
    const decoder = new TextDecoder('utf-8', { fatal: true })
    const parts: string[] = []
    let bytes = 0
    stream.on('data', (chunk) => {
      bytes += chunk.length
      try {
        if (bytes > byteLimit) throw new Error('DOCX XML size exceeded')
        parts.push(decoder.decode(chunk, { stream: true }))
      } catch (error) { stream.pause(); reject(error) }
    }).on('error', reject).on('end', () => {
      try { resolve(parts.join('') + decoder.decode()) }
      catch (error) { reject(error) }
    }).resume()
  })
}

async function validateDocx(bytes: Buffer) {
  try {
    if (!bytes.subarray(0, 4).equals(Buffer.from([0x50, 0x4b, 0x03, 0x04]))) throw new Error('Missing ZIP signature')
    const zip = await JSZip.loadAsync(bytes)
    if (Object.keys(zip.files).length > 3000 || zip.file(/(?:^|\/)vbaProject\.bin$/i).length) throw new Error('Unsupported DOCX archive')
    const types = zip.file('[Content_Types].xml')
    const relationships = zip.file('_rels/.rels')
    const body = zip.file('word/document.xml')
    if (!types || !relationships || !body) throw new Error('Missing DOCX XML')
    let documentPart = false
    const typeParser = sax.parser(true, { xmlns: true, strictEntities: true })
    typeParser.ondoctype = () => { throw new Error('DOCTYPE is not allowed') }
    typeParser.onopentag = (tag) => {
      if (tag.local === 'Override' && tag.uri === 'http://schemas.openxmlformats.org/package/2006/content-types'
        && tag.attributes.PartName?.value === '/word/document.xml'
        && tag.attributes.ContentType?.value === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml') documentPart = true
    }
    typeParser.write(await readXml(types, 1024 * 1024)).close()
    const relationshipsParser = sax.parser(true, { xmlns: true, strictEntities: true })
    relationshipsParser.ondoctype = typeParser.ondoctype
    let mainRelationship = false
    relationshipsParser.onopentag = (tag) => {
      if (tag.local === 'Relationship' && tag.uri === 'http://schemas.openxmlformats.org/package/2006/relationships'
        && /^(?:http:\/\/schemas\.openxmlformats\.org\/officeDocument\/2006|http:\/\/purl\.oclc\.org\/ooxml\/officeDocument)\/relationships\/officeDocument$/.test(tag.attributes.Type?.value ?? '')
        && /^\/?word\/document\.xml$/.test(tag.attributes.Target?.value ?? '') && tag.attributes.TargetMode?.value !== 'External') mainRelationship = true
    }
    relationshipsParser.write(await readXml(relationships, 1024 * 1024)).close()
    let bodyFound = false
    let depth = 0
    const docParser = sax.parser(true, { xmlns: true, strictEntities: true })
    const namespaces = new Set(['http://schemas.openxmlformats.org/wordprocessingml/2006/main', 'http://purl.oclc.org/ooxml/wordprocessingml/main'])
    docParser.ondoctype = typeParser.ondoctype
    docParser.onopentag = (tag) => {
      depth++
      if (depth === 1 && (tag.local !== 'document' || !namespaces.has(tag.uri))) throw new Error('Invalid DOCX root')
      if (depth === 2 && tag.local === 'body' && namespaces.has(tag.uri)) bodyFound = true
    }
    docParser.onclosetag = () => { depth-- }
    docParser.write(await readXml(body, 12 * 1024 * 1024)).close()
    if (!documentPart || !mainRelationship || !bodyFound) throw new Error('Missing main document part')
  } catch {
    throw new HttpError(422, 'The file could not be read as a standard DOCX document.')
  }
}

export async function validateDocument(name: string, bytes: Buffer): Promise<{ mime: DocumentMime; sha256: string }> {
  if (!bytes.length) throw new HttpError(422, 'The file is empty.')
  if (bytes.length > MAX_UPLOAD_BYTES) throw new HttpError(413, 'The file exceeds the 20 MB limit.')
  const mime = /\.pdf$/i.test(name) ? PDF_MIME : DOCX_MIME
  if (mime === PDF_MIME) await validatePdf(bytes)
  else await validateDocx(bytes)
  return { mime, sha256: createHash('sha256').update(bytes).digest('hex') }
}
