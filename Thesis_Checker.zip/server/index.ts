import { createServer } from 'node:http'
import { createHandler } from './http.ts'
import { createSupabaseService } from './service.ts'

function required(name: string) {
  const value = process.env[name]?.trim()
  if (!value) throw new Error(`Missing server environment variable ${name}.`)
  return value
}

const url = new URL(required('SUPABASE_URL'))
const origins = new Set(required('APP_ORIGINS').split(',').map((input) => {
  const origin = new URL(input.trim())
  if (origin.protocol !== 'https:' && !(process.env.NODE_ENV !== 'production' && ['localhost', '127.0.0.1'].includes(origin.hostname))) {
    throw new Error('APP_ORIGINS must use HTTPS in production.')
  }
  return origin.origin
}))
if (url.protocol !== 'https:' && !(process.env.NODE_ENV !== 'production' && ['localhost', '127.0.0.1'].includes(url.hostname))) {
  throw new Error('SUPABASE_URL must use HTTPS in production.')
}

const service = createSupabaseService({ url: url.origin, publishableKey: required('SUPABASE_PUBLISHABLE_KEY'), secretKey: required('SUPABASE_SECRET_KEY') })
const handle = createHandler(service, origins)
const port = Number(process.env.PORT ?? 8080)
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT must be a valid TCP port.')

const server = createServer({ requestTimeout: 60_000, headersTimeout: 10_000 }, (request, response) => { void handle(request, response) })
server.listen(port, '0.0.0.0', () => console.log(JSON.stringify({ level: 'info', event: 'workspace_api_listening', port })))

let cleanupRunning = false
const cleanup = async () => {
  if (cleanupRunning) return
  cleanupRunning = true
  try { await service.cleanAbandonedUploads() }
  catch { console.error(JSON.stringify({ level: 'error', event: 'abandoned_upload_cleanup_failed' })) }
  finally { cleanupRunning = false }
}
const timer = setInterval(() => { void cleanup() }, 5 * 60_000).unref()
void cleanup()

for (const signal of ['SIGTERM', 'SIGINT'] as const) process.once(signal, () => {
  clearInterval(timer)
  server.close()
})
