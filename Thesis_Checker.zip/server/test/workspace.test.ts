import assert from 'node:assert/strict'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { Readable } from 'node:stream'
import test from 'node:test'
import JSZip from 'jszip'
import { DOCX_MIME, MAX_UPLOAD_BYTES, PDF_MIME } from '../../shared/workspace.ts'
import { HttpError } from '../errors.ts'
import { createHandler } from '../http.ts'
import { createSupabaseService } from '../service.ts'
import type { WorkspaceService } from '../service.ts'

const first = '11111111-1111-1111-1111-111111111111'
const second = '22222222-2222-2222-2222-222222222222'
const document = '33333333-3333-3333-3333-333333333333'
const version = '44444444-4444-4444-4444-444444444444'
const origin = 'https://student.example.invalid'
const emptyHistory = { documents: [], events: [], deletingAccount: false }

function setup(overrides: Partial<WorkspaceService> = {}) {
  const service: WorkspaceService = {
    ready: async () => true,
    authenticate: async (token) => token === 'student-one' ? { id: first, email: 'one@example.invalid' }
      : token === 'student-two' ? { id: second, email: 'two@example.invalid' } : null,
    history: async () => emptyHistory,
    reserve: async () => ({ id: version, document_id: document, object_key: `${first}/${document}/${version}`, state: 'uploading', existing: false }),
    storeFile: async () => {},
    finishUpload: async () => {},
    fileLink: async (owner) => {
      if (owner !== first) throw new HttpError(404, 'The document version is unavailable.')
      return 'https://storage.example.invalid/download'
    },
    deleteDocument: async (owner) => { if (owner !== first) throw new HttpError(404, 'The document is unavailable.') },
    deleteAccount: async () => {},
    cleanAbandonedUploads: async () => {},
    ...overrides,
  }
  const logs: object[] = []
  const handle = createHandler(service, new Set([origin]), (entry) => logs.push(entry))
  return { handle, logs }
}

async function request(handle: ReturnType<typeof createHandler>, method: string, url: string, headers: Record<string, string> = {}, bytes?: Buffer) {
  const incoming = Object.assign(Readable.from(bytes ? [bytes] : []), { method, url, headers, complete: true })
  const responseHeaders = new Map<string, string>()
  const outgoing = {
    status: 0, text: '', destroyed: false, headersSent: false,
    setHeader(name: string, value: string) { responseHeaders.set(name.toLowerCase(), value) },
    writeHead(status: number, additional: Record<string, string> = {}) {
      this.status = status
      this.headersSent = true
      for (const [key, value] of Object.entries(additional)) this.setHeader(key, value)
      return this
    },
    end(data = '') { this.text = data; return this },
  }
  await handle(incoming as unknown as IncomingMessage, outgoing as unknown as ServerResponse)
  return { status: outgoing.status, body: outgoing.text ? JSON.parse(outgoing.text) : null, headers: responseHeaders }
}

const authorization = { authorization: 'Bearer student-one', origin }
const fileHeaders = (name: string) => ({ ...authorization, 'x-file-name': encodeURIComponent(name), 'idempotency-key': version })

async function docxFixture(body = '<w:body><w:p><w:r><w:t>Thesis fixture.</w:t></w:r></w:p></w:body>') {
  const zip = new JSZip()
  zip.file('[Content_Types].xml', '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
  zip.file('_rels/.rels', '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
  zip.file('word/document.xml', `<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">${body}</w:document>`)
  return zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' })
}

function pdfFixture() {
  const objects = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << >> >>',
  ]
  const offsets: number[] = []
  let file = '%PDF-1.7\n'
  for (const [index, object] of objects.entries()) {
    offsets.push(file.length)
    file += `${index + 1} 0 obj\n${object}\nendobj\n`
  }
  const xref = file.length
  file += `xref\n0 4\n0000000000 65535 f \n${offsets.map((offset) => `${String(offset).padStart(10, '0')} 00000 n \n`).join('')}trailer\n<< /Size 4 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`
  return Buffer.from(file, 'ascii')
}

test('requires a verified session, rejects foreign origins, and exposes a dependency readiness check', async () => {
  const { handle } = setup({ ready: async () => false })
  assert.equal((await request(handle, 'GET', '/healthz')).status, 200)
  assert.equal((await request(handle, 'GET', '/readyz')).status, 503)
  assert.equal((await request(handle, 'GET', '/api/v1/documents')).status, 401)
  assert.equal((await request(handle, 'GET', '/api/v1/documents', { authorization: 'Bearer expired-session' })).status, 401)
  assert.equal((await request(handle, 'GET', '/api/v1/documents', { ...authorization, origin: 'https://unrelated.example.invalid' })).status, 403)
  const preflight = await request(handle, 'OPTIONS', '/api/v1/documents', { origin })
  assert.equal(preflight.status, 204)
  assert.equal(preflight.headers.get('access-control-allow-origin'), origin)
})

test('accepts a valid DOCX and PDF revision and publishes readiness only after private storage succeeds', async () => {
  const calls: string[] = []
  const { handle } = setup({
    reserve: async (owner, upload) => {
      assert.equal(owner, first)
      assert.match(upload.sha256, /^[0-9a-f]{64}$/)
      assert.equal(upload.documentId, upload.mime === PDF_MIME ? document : null)
      calls.push(`reserve:${upload.mime}`)
      return { id: version, document_id: document, object_key: `${first}/${document}/${version}`, state: 'uploading', existing: false }
    },
    storeFile: async (key, file, mime) => {
      assert.equal(key, `${first}/${document}/${version}`)
      assert.ok(file.length > 0)
      calls.push(`store:${mime}`)
    },
    finishUpload: async (owner, id) => { assert.deepEqual([owner, id], [first, version]); calls.push('ready') },
  })
  assert.equal((await request(handle, 'POST', '/api/v1/documents', fileHeaders('Draft.docx'), await docxFixture())).status, 201)
  assert.equal((await request(handle, 'POST', `/api/v1/documents/${document}/versions`, fileHeaders('Draft 2.pdf'), pdfFixture())).status, 201)
  assert.deepEqual(calls, [`reserve:${DOCX_MIME}`, `store:${DOCX_MIME}`, 'ready', `reserve:${PDF_MIME}`, `store:${PDF_MIME}`, 'ready'])
})

test('rejects disguised, malformed, empty, oversized and path-like files before reserving storage', async () => {
  const { handle } = setup({ reserve: async () => assert.fail('Invalid uploads must not reserve storage') })
  const route = '/api/v1/documents'
  assert.equal((await request(handle, 'POST', route, fileHeaders('fake.pdf'), Buffer.from('plain text'))).status, 422)
  assert.equal((await request(handle, 'POST', route, fileHeaders('fake.docx'), await docxFixture('<w:body>'))).status, 422)
  assert.equal((await request(handle, 'POST', route, fileHeaders('empty.pdf'), Buffer.alloc(0))).status, 422)
  assert.equal((await request(handle, 'POST', route, fileHeaders('sample.zip'), await docxFixture())).status, 415)
  assert.equal((await request(handle, 'POST', route, fileHeaders('../draft.pdf'), pdfFixture())).status, 400)
  assert.equal((await request(handle, 'POST', route, { ...fileHeaders('large.pdf'), 'content-length': String(MAX_UPLOAD_BYTES + 1) })).status, 413)
})

test('returns an existing ready version and preserves a pending reservation after a storage failure', async () => {
  let stored = 0
  let reservationState: 'new' | 'ready' | 'pending' = 'ready'
  const { handle, logs } = setup({
    reserve: async () => ({ id: version, document_id: document, object_key: 'path', state: reservationState === 'ready' ? 'ready' : 'uploading', existing: reservationState !== 'new' }),
    storeFile: async () => { stored++; throw new HttpError(503, 'Private storage is unavailable.', 'storage_unavailable') },
    finishUpload: async () => assert.fail('A failed storage call must not mark a version ready'),
  })
  const file = await docxFixture()
  assert.equal((await request(handle, 'POST', '/api/v1/documents', fileHeaders('Draft.docx'), file)).status, 200)
  assert.equal(stored, 0)
  reservationState = 'new'
  assert.equal((await request(handle, 'POST', '/api/v1/documents', fileHeaders('Draft.docx'), file)).status, 503)
  reservationState = 'pending'
  assert.equal((await request(handle, 'POST', '/api/v1/documents', fileHeaders('Draft.docx'), file)).status, 409)
  assert.equal(stored, 1)
  assert.equal(logs.length, 1)
})

test('scopes download and deletion to the authenticated owner and requires password confirmation for account deletion', async () => {
  let deleted = 0
  const { handle } = setup({ deleteAccount: async (student, token, password) => {
    assert.deepEqual([student.id, token, password], [first, 'student-one', 'confirmed-password'])
    deleted++
  } })
  const outsider = { authorization: 'Bearer student-two', origin }
  const download = `/api/v1/documents/${document}/versions/${version}/download`
  assert.equal((await request(handle, 'GET', download, outsider)).status, 404)
  assert.equal((await request(handle, 'GET', download, authorization)).body.expiresIn, 60)
  assert.equal((await request(handle, 'DELETE', `/api/v1/documents/${document}`, outsider)).status, 404)
  assert.equal((await request(handle, 'DELETE', `/api/v1/documents/${document}`, authorization)).status, 204)
  assert.equal((await request(handle, 'DELETE', '/api/v1/account', authorization, Buffer.from('{}'))).status, 400)
  assert.equal((await request(handle, 'DELETE', '/api/v1/account', authorization, Buffer.from('{"password":"confirmed-password"}'))).status, 204)
  assert.equal(deleted, 1)
})

test('Supabase adapter verifies the caller token and filters downloads by the authenticated owner before asking Storage for a link', async (context) => {
  const provider = 'https://supabase.example.invalid'
  let storageCalls = 0
  context.mock.method(globalThis, 'fetch', async (input: Parameters<typeof fetch>[0], init?: RequestInit) => {
    const url = new URL(input instanceof Request ? input.url : input)
    assert.equal(url.origin, provider)
    if (url.pathname === '/auth/v1/user') {
      assert.equal(new Headers(init?.headers).get('Authorization'), 'Bearer student-two')
      return Response.json({ id: second, email: 'two@example.invalid', email_confirmed_at: '2026-11-06T00:00:00Z' })
    }
    if (url.pathname === '/rest/v1/thesis_versions') {
      assert.equal(url.searchParams.get('owner_id'), `eq.${second}`)
      assert.equal(url.searchParams.get('document_id'), `eq.${document}`)
      assert.equal(url.searchParams.get('state'), 'eq.ready')
      assert.equal(url.searchParams.get('document.deleting'), 'eq.false')
      return Response.json([])
    }
    storageCalls++
    return Response.json({ error: 'Unexpected endpoint' }, { status: 500 })
  })
  const service = createSupabaseService({ url: provider, publishableKey: 'public-test', secretKey: 'server-test' })
  const student = await service.authenticate('student-two')
  assert.equal(student?.id, second)
  await assert.rejects(service.fileLink(second, document, version), { status: 404 })
  assert.equal(storageCalls, 0)
})
