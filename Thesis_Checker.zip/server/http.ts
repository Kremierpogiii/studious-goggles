import { randomUUID } from 'node:crypto'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { MAX_UPLOAD_BYTES } from '../shared/workspace.ts'
import { HttpError } from './errors.ts'
import type { WorkspaceService } from './service.ts'
import { readFileName, validateDocument } from './validation.ts'

const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
type RateBucket = { expires: number; count: number }

function header(request: IncomingMessage, name: string) {
  const value = request.headers[name]
  return typeof value === 'string' ? value : undefined
}

async function readBody(request: IncomingMessage, limit: number) {
  const contentLength = header(request, 'content-length')
  if (contentLength && (!/^\d+$/.test(contentLength) || Number(contentLength) > limit)) {
    throw new HttpError(413, 'The request exceeds the size limit.')
  }
  const chunks: Buffer[] = []
  let total = 0
  const stream = request.iterator({ destroyOnReturn: false })
  for await (const chunk of stream) {
    const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    total += bytes.length
    if (total > limit) throw new HttpError(413, 'The request exceeds the size limit.')
    chunks.push(bytes)
  }
  if (contentLength && Number(contentLength) !== total) throw new HttpError(400, 'The upload was interrupted.')
  return Buffer.concat(chunks, total)
}

function json(response: ServerResponse, status: number, payload: unknown) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' })
  response.end(JSON.stringify(payload))
}

export function createHandler(service: WorkspaceService, origins: ReadonlySet<string>, log = (entry: object) => console.error(JSON.stringify(entry))) {
  const rates = new Map<string, RateBucket>()
  let lastSweep = 0
  let activeUploads = 0

  function rateLimit(key: string, maximum: number) {
    const now = Date.now()
    if (now > lastSweep + 60_000) {
      for (const [id, record] of rates) if (record.expires <= now) rates.delete(id)
      lastSweep = now
    }
    const previous = rates.get(key)
    const bucket = previous && previous.expires > now ? previous : { expires: now + 60_000, count: 0 }
    if (bucket.count >= maximum) throw new HttpError(429, 'Too many requests. Wait one minute and try again.', 'rate_limited')
    if (rates.size >= 10_000 && !previous) throw new HttpError(503, 'The service is busy. Try again shortly.', 'service_busy')
    bucket.count++
    rates.set(key, bucket)
  }

  return async (request: IncomingMessage, response: ServerResponse) => {
    const requestId = randomUUID()
    const origin = header(request, 'origin')
    response.setHeader('Cache-Control', 'private, no-store')
    response.setHeader('X-Content-Type-Options', 'nosniff')
    response.setHeader('Referrer-Policy', 'no-referrer')
    response.setHeader('X-Request-Id', requestId)
    response.setHeader('Vary', 'Origin')

    try {
      if (origin && !origins.has(origin)) throw new HttpError(403, 'This site is not authorized to call the workspace API.', 'origin_denied')
      if (origin) response.setHeader('Access-Control-Allow-Origin', origin)
      const path = new URL(request.url ?? '/', 'http://api.internal').pathname
      if (request.method === 'OPTIONS' && path.startsWith('/api/v1/')) {
        response.writeHead(204, {
          'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
          'Access-Control-Allow-Headers': 'Authorization, Content-Type, Idempotency-Key, X-File-Name',
          'Access-Control-Max-Age': '600',
        }).end()
        return
      }
      if (request.method === 'GET' && path === '/healthz') return json(response, 200, { status: 'ok' })
      if (request.method === 'GET' && path === '/readyz') {
        if (!await service.ready()) throw new HttpError(503, 'The API dependencies are not ready.', 'service_unavailable')
        return json(response, 200, { status: 'ready' })
      }
      if (!path.startsWith('/api/v1/')) throw new HttpError(404, 'This endpoint does not exist.')

      const token = /^Bearer ([A-Za-z0-9_.-]{1,8192})$/i.exec(header(request, 'authorization') ?? '')?.[1]
      if (!token) throw new HttpError(401, 'Sign in to access your documents.', 'session_required')
      const student = await service.authenticate(token)
      if (!student) throw new HttpError(401, 'Sign in with a verified email to access your documents.', 'session_required')
      rateLimit(student.id, 60)

      const documentRoute = /^\/api\/v1\/documents\/([^/]+)(?:\/versions(?:\/([^/]+)\/download)?)?$/.exec(path)
      const documentId = documentRoute?.[1]
      const versionId = documentRoute?.[2]
      if ((documentId && !uuid.test(documentId)) || (versionId && !uuid.test(versionId))) throw new HttpError(404, 'The document is unavailable.')

      if (request.method === 'GET' && path === '/api/v1/documents') return json(response, 200, await service.history(student.id))
      if (request.method === 'GET' && documentId && versionId) {
        const url = await service.fileLink(student.id, documentId, versionId)
        return json(response, 200, { url, expiresIn: 60 })
      }
      if (request.method === 'POST' && (path === '/api/v1/documents' || (documentId && path.endsWith('/versions')))) {
        const requestKey = header(request, 'idempotency-key') ?? ''
        if (!uuid.test(requestKey)) throw new HttpError(400, 'A valid upload identifier is required.')
        const name = readFileName(header(request, 'x-file-name'))
        rateLimit(`${student.id}:upload`, 8)
        if (activeUploads >= 4) throw new HttpError(503, 'Uploads are busy. Try again shortly.', 'service_busy')
        activeUploads++
        try {
          const file = await readBody(request, MAX_UPLOAD_BYTES)
          const { mime, sha256 } = await validateDocument(name, file)
          const reservation = await service.reserve(student.id, { documentId: documentId ?? null, name, mime, size: file.length, sha256, requestKey })
          const payload = { id: reservation.id, documentId: reservation.document_id }
          if (reservation.existing) {
            if (reservation.state === 'ready') return json(response, 200, payload)
            throw new HttpError(409, 'This upload is already pending. Refresh the document history before retrying.', 'upload_pending')
          }
          if (!reservation.object_key) throw new HttpError(503, 'The upload reservation is unavailable.', 'database_unavailable')
          await service.storeFile(reservation.object_key, file, mime)
          await service.finishUpload(student.id, reservation.id)
          return json(response, 201, payload)
        } finally { activeUploads-- }
      }
      if (request.method === 'DELETE' && documentId && path === `/api/v1/documents/${documentId}`) {
        await service.deleteDocument(student.id, documentId)
        response.writeHead(204).end()
        return
      }
      if (request.method === 'DELETE' && path === '/api/v1/account') {
        rateLimit(`${student.id}:account`, 4)
        let password: unknown
        const body = await readBody(request, 4096)
        try { password = JSON.parse(body.toString('utf8'))?.password }
        catch { throw new HttpError(400, 'A password is required to confirm account deletion.') }
        if (typeof password !== 'string' || !password || password.length > 256) throw new HttpError(400, 'A password is required to confirm account deletion.')
        await service.deleteAccount(student, token, password)
        response.writeHead(204).end()
        return
      }
      throw new HttpError(404, 'This endpoint does not exist.')
    } catch (error) {
      const known = error instanceof HttpError ? error : new HttpError(500, 'The request could not be completed. Try again shortly.', 'unexpected_error')
      if (known.status >= 500) log({ level: 'error', event: 'workspace_request_failed', code: known.code, requestId, status: known.status })
      if (known.status === 429) response.setHeader('Retry-After', '60')
      if (!request.complete) response.setHeader('Connection', 'close')
      if (!response.destroyed && !response.headersSent) json(response, known.status, { error: known.message, code: known.code, requestId })
    }
  }
}
