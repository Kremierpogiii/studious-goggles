export class HttpError extends Error {
  constructor(status: number, message: string, code = 'request_failed') {
    super(message)
    this.status = status
    this.code = code
  }

  readonly status: number
  readonly code: string
}
