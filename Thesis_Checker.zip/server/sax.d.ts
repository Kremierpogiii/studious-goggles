declare module 'sax' {
  interface Tag {
    local: string
    uri: string
    attributes: Record<string, { value: string }>
  }
  interface Parser {
    onopentag: (tag: Tag) => void
    onclosetag: () => void
    ondoctype: () => void
    write(xml: string): Parser
    close(): void
  }
  const sax: { parser(strict: boolean, options: { xmlns: boolean; strictEntities: boolean }): Parser }
  export default sax
}
