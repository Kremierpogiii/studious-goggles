import { createClient } from '@supabase/supabase-js'
import type { DocumentMime, WorkspaceHistory } from '../shared/workspace.ts'
import { HttpError } from './errors.ts'

export interface Student { id: string; email: string }
export interface UploadInput {
  documentId: string | null; name: string; mime: DocumentMime; size: number; sha256: string; requestKey: string
}
export interface Reservation {
  id: string; document_id: string; object_key?: string; state: 'uploading' | 'ready'; existing: boolean
}
export interface WorkspaceService {
  ready(): Promise<boolean>
  authenticate(token: string): Promise<Student | null>
  history(owner: string): Promise<WorkspaceHistory>
  reserve(owner: string, input: UploadInput): Promise<Reservation>
  storeFile(key: string, file: Buffer, mime: DocumentMime): Promise<void>
  finishUpload(owner: string, version: string): Promise<void>
  fileLink(owner: string, document: string, version: string): Promise<string>
  deleteDocument(owner: string, document: string): Promise<void>
  deleteAccount(student: Student, token: string, password: string): Promise<void>
  cleanAbandonedUploads(): Promise<void>
}

export interface SupabaseConfiguration { url: string; publishableKey: string; secretKey: string }

const rpcErrors: Record<string, [number, string]> = {
  document_unavailable: [404, 'The document is unavailable.'],
  account_deleting: [409, 'Account deletion is in progress.'],
  idempotency_conflict: [409, 'This upload identifier was already used for a different file.'],
  uploads_pending: [409, 'A file upload is still pending. Try deletion again after the upload finishes or expires.'],
  too_many_uploads: [429, 'Too many uploads are pending. Try again after they finish or expire.'],
  storage_quota: [409, 'Your workspace limit is 100 versions or 250 MB. Delete a document to make space.'],
}

function checkRpc<T>(data: T | { error: string } | null, error: unknown): T {
  if (error || !data) throw new HttpError(503, 'The document database is temporarily unavailable.', 'database_unavailable')
  if (typeof data === 'object' && 'error' in data) {
    const [status, message] = rpcErrors[data.error] ?? [503, 'The document database is temporarily unavailable.']
    throw new HttpError(status, message, data.error)
  }
  return data
}

const fetchWithTimeout: typeof fetch = (input, init) => {
  const timeout = AbortSignal.timeout(20_000)
  return fetch(input, { ...init, signal: init?.signal ? AbortSignal.any([init.signal, timeout]) : timeout })
}

export function createSupabaseService(configuration: SupabaseConfiguration): WorkspaceService {
  const { url, publishableKey, secretKey } = configuration
  const auth = { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
  const options = { auth, global: { fetch: fetchWithTimeout } }
  const verification = createClient(url, publishableKey, options)
  const service = createClient(url, secretKey, options)
  const bucket = service.storage.from('thesis-checker-private')

  async function removeFiles(keys: string[]) {
    if (keys.length === 0) return
    const { error } = await bucket.remove(keys)
    if (error) throw new HttpError(503, 'Private storage is temporarily unavailable. Retry deletion to finish the request.', 'storage_unavailable')
  }

  async function beginDelete(owner: string, document: string | null) {
    const { data, error } = await service.rpc('thesis_begin_delete', { p_owner: owner, p_document: document })
    const { keys } = checkRpc<{ keys: string[] }>(data, error)
    await removeFiles(keys)
  }

  return {
    async ready() {
      const [database, storage] = await Promise.all([
        service.from('thesis_documents').select('id', { head: true }).limit(1),
        service.storage.getBucket('thesis-checker-private'),
      ])
      return !database.error && !storage.error && storage.data?.public === false
    },

    async authenticate(token) {
      const { data, error } = await verification.auth.getUser(token)
      if (error && (!error.status || error.status >= 500)) throw new HttpError(503, 'The authentication service is temporarily unavailable.', 'auth_unavailable')
      const user = data.user
      return user?.email && user.email_confirmed_at && !user.is_anonymous ? { id: user.id, email: user.email } : null
    },

    async history(owner) {
      const [documents, events, account] = await Promise.all([
        service.from('thesis_documents').select('id,title,created_at,deleting,versions:thesis_versions(id,version_number,file_name,mime_type,size_bytes,state,created_at)').eq('owner_id', owner).order('created_at', { ascending: false }),
        service.from('thesis_events').select('id,document_id,kind,created_at').eq('owner_id', owner).order('id', { ascending: false }).limit(12),
        service.from('thesis_accounts').select('deletion_requested_at').eq('id', owner).maybeSingle(),
      ])
      if (documents.error || events.error || account.error) throw new HttpError(503, 'Document history could not be loaded.', 'database_unavailable')
      const history = { documents: documents.data, events: events.data, deletingAccount: Boolean(account.data?.deletion_requested_at) } as WorkspaceHistory
      for (const document of history.documents) document.versions.sort((a, b) => b.version_number - a.version_number)
      return history
    },

    async reserve(owner, input) {
      const { data, error } = await service.rpc('thesis_reserve_upload', {
        p_owner: owner, p_document: input.documentId, p_name: input.name, p_mime: input.mime,
        p_size: input.size, p_sha: input.sha256, p_request: input.requestKey,
      })
      return checkRpc<Reservation>(data, error)
    },

    async storeFile(key, file, mime) {
      const { error } = await bucket.upload(key, file, { contentType: mime, upsert: false, cacheControl: '0' })
      if (error) throw new HttpError(503, 'The upload could not be confirmed. Its reservation will expire in 30 minutes.', 'storage_unavailable')
    },

    async finishUpload(owner, version) {
      const { data, error } = await service.rpc('thesis_finish_upload', { p_owner: owner, p_version: version })
      if (error || data !== true) throw new HttpError(503, 'The saved file could not be confirmed. Check your document history before retrying.', 'database_unavailable')
    },

    async fileLink(owner, document, version) {
      const { data, error } = await service.from('thesis_versions')
        .select('object_key,file_name,document:thesis_documents!inner(deleting)')
        .eq('id', version).eq('owner_id', owner).eq('document_id', document).eq('state', 'ready').eq('document.deleting', false).maybeSingle()
      if (error) throw new HttpError(503, 'The document database is temporarily unavailable.', 'database_unavailable')
      if (!data) throw new HttpError(404, 'The document version is unavailable.')
      const { data: link, error: storageError } = await bucket.createSignedUrl(data.object_key, 60, { download: data.file_name })
      if (storageError || !link) throw new HttpError(503, 'A download link could not be created.', 'storage_unavailable')
      return link.signedUrl
    },

    async deleteDocument(owner, document) {
      await beginDelete(owner, document)
      const { error } = await service.rpc('thesis_finish_document_delete', { p_owner: owner, p_document: document })
      if (error) throw new HttpError(503, 'Deletion could not be confirmed. Retry to finish the request.', 'database_unavailable')
    },

    async deleteAccount(student, token, password) {
      const confirmation = createClient(url, publishableKey, options)
      const { data, error } = await confirmation.auth.signInWithPassword({ email: student.email, password })
      if (error && (!error.status || error.status >= 500)) throw new HttpError(503, 'Account confirmation is temporarily unavailable.', 'auth_unavailable')
      if (data.user?.id !== student.id || !data.session) throw new HttpError(403, 'The password could not be verified.', 'password_not_verified')
      try {
        await beginDelete(student.id, null)
        const signout = await service.auth.admin.signOut(token, 'global')
        if (signout.error) throw new HttpError(503, 'Sessions could not be revoked. Retry account deletion.', 'auth_unavailable')
        const removed = await service.auth.admin.deleteUser(student.id)
        if (removed.error) throw new HttpError(503, 'The account could not be deleted. Sign in and retry.', 'auth_unavailable')
      } finally {
        await service.auth.admin.signOut(data.session.access_token, 'local').catch(() => undefined)
      }
    },

    async cleanAbandonedUploads() {
      const { data, error } = await service.rpc('thesis_expired_uploads')
      const expired = checkRpc<{ id: string; owner_id: string; object_key: string }[]>(data, error)
      await removeFiles(expired.map(({ object_key }) => object_key))
      for (const version of expired) {
        const { error: cleanupError } = await service.rpc('thesis_purge_stale_upload', { p_owner: version.owner_id, p_version: version.id })
        if (cleanupError) throw new HttpError(503, 'Upload cleanup could not finish.', 'database_unavailable')
      }
    },
  }
}
