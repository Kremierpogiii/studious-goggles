export const MAX_UPLOAD_BYTES = 20 * 1024 * 1024
export const PDF_MIME = 'application/pdf'
export const DOCX_MIME = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
export type DocumentMime = typeof PDF_MIME | typeof DOCX_MIME

export interface StoredVersion {
  id: string
  version_number: number
  file_name: string
  mime_type: DocumentMime
  size_bytes: number
  state: 'uploading' | 'ready'
  created_at: string
}

export interface StoredDocument {
  id: string
  title: string
  created_at: string
  deleting: boolean
  versions: StoredVersion[]
}

export interface StoredEvent {
  id: number
  document_id: string | null
  kind: 'version_saved' | 'document_deleted'
  created_at: string
}

export interface WorkspaceHistory {
  documents: StoredDocument[]
  events: StoredEvent[]
  deletingAccount: boolean
}
